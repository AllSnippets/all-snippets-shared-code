// ZAČETEK KODE: JavaScript za štetje aktivnih filtrov
(function() {
    // Počakaj, da se sharedPageConfig naloži
    function initActiveFiltersCounter() {
        if (!window.sharedPageConfig) {
            setTimeout(initActiveFiltersCounter, 50);
            return;
        }
        
        const { pluginSlug, buildSelector } = window.sharedPageConfig;
        
        // Funkcija za štetje aktivnih filtrov
        function updateActiveFiltersCount() {
            let activeCount = 0;
            
            // Preveri filter_active (če ni 'all')
            const filterActiveSelector = buildSelector('.gp-filter-radio--input[name="filter_active"]');
            const filterActive = document.querySelector(filterActiveSelector + ':checked');
            if (filterActive && filterActive.value !== 'all') {
                activeCount++;
            }
            
            // Preveri filter_global (če ni 'all')
            const filterGlobalSelector = buildSelector('.gp-filter-radio--input[name="filter_global"]');
            const filterGlobal = document.querySelector(filterGlobalSelector + ':checked');
            if (filterGlobal && filterGlobal.value !== 'all') {
                activeCount++;
            }
            
            // Preveri filter_scope (exclude)
            const locationExclude = document.querySelectorAll('.gp-filter-toggle--input[value="exclude"]:checked');
            activeCount += locationExclude.length;
            
            // Preveri filter_code_type (exclude)
            const codeTypeExclude = document.querySelectorAll('.gp-filter-toggle--input[name^="filter_code_type"][value="exclude"]:checked');
            activeCount += codeTypeExclude.length;
            
            // Preveri filter_tag (exclude)
            const tagExclude = document.querySelectorAll('.gp-filter-dropdown--input[name^="filter_tag"][value="exclude"]:checked');
            activeCount += tagExclude.length;
            
            // Preveri filter_category (exclude)
            const categoryExclude = document.querySelectorAll('.gp-filter-dropdown--input[name^="filter_category"][value="exclude"]:checked');
            activeCount += categoryExclude.length;
            
            // Preveri filter_folder (exclude)
            const folderExclude = document.querySelectorAll('.gp-filter-dropdown--input[name^="filter_folder"][value="exclude"]:checked');
            activeCount += folderExclude.length;
            
            // Posodobi števec
            const counterElement = document.querySelector(buildSelector('.gp-filter-info--count-bubble'));
            if (counterElement) {
                counterElement.textContent = activeCount;
            }
        }
        
        // Delegiran event listener za spremembe filtrov
        // OPOMBA: Delegiran listener deluje tudi za dinamično dodane elemente (po AJAX refresh)
        document.addEventListener('change', function(e) {
            const target = e.target;
            const filterActiveSelector = buildSelector('.gp-filter-radio--input[name="filter_active"]');
            const filterGlobalSelector = buildSelector('.gp-filter-radio--input[name="filter_global"]');
            
            if (target.matches(filterActiveSelector) || 
                target.matches(filterGlobalSelector) ||
                target.matches('.gp-filter-toggle--input') ||
                target.matches('.gp-filter-toggle--input[name^="filter_code_type"]') ||
                target.matches('.gp-filter-dropdown--input[name^="filter_tag"]') ||
                target.matches('.gp-filter-dropdown--input[name^="filter_category"]') ||
                target.matches('.gp-filter-dropdown--input[name^="filter_folder"]')) {
                updateActiveFiltersCount();
            }
        });
        
        // Inicializiraj števec ob nalaganju strani
        updateActiveFiltersCount();
        
        // Posodobi števec tudi po AJAX refresh-u
        // Dinamično ime eventa na podlagi plugin slug-a
        const eventName = `${pluginSlug.replace(/-/g, '')}TableRefreshed`;
        document.addEventListener(eventName, function() {
            setTimeout(function() {
                updateActiveFiltersCount();
            }, 100);
        });
        
        // Naredi funkcijo globalno dostopno
        window.updateActiveFiltersCount = updateActiveFiltersCount;
    }
    
    initActiveFiltersCounter();
})();
// KONEC KODE: JavaScript za štetje aktivnih filtrov


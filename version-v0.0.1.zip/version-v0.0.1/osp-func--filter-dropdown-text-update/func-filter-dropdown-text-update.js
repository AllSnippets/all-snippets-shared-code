// ZAČETEK KODE: JavaScript za univerzalno posodabljanje dropdown teksta z delegiranimi event listenerji
(function() {
    // Univerzalna funkcija za posodabljanje dropdown teksta
    function updateDropdownText(inputElement) {
        // Poišči root element dropdown-a (najbližji parent z .gp-filter-dropdown--root)
        const root = inputElement.closest('.gp-filter-dropdown--root');
        if (!root) return;
        
        // Univerzalno: poišči prvi element s KATERIMKOLI data atributom v root-u
        const allElements = root.querySelectorAll('*');
        let firstOption = null;
        let dataAttribute = null;
        
        for (let i = 0; i < allElements.length; i++) {
            const element = allElements[i];
            const attributes = element.attributes;
            for (let j = 0; j < attributes.length; j++) {
                const attr = attributes[j];
                if (attr.name.startsWith('data-') && attr.name !== 'data-plugin-slug' && attr.name !== 'data-page-slug' && attr.name !== 'data-admin-obj-name' && attr.name !== 'data-page-url') {
                    firstOption = element;
                    dataAttribute = attr.name;
                    break;
                }
            }
            if (firstOption) break;
        }
        
        if (!firstOption || !dataAttribute) return;
        
        // Iz data atributa izpelji tip (npr. data-tag -> tag, data-category -> category)
        const itemType = dataAttribute.replace('data-', '');
        
        // Dinamično sestavi vrednosti za "No Item" opcijo
        const noItemValue = '__no_' + itemType + '__';
        
        // Poišči vse input elemente z exclude vrednostjo v tem dropdown-u
        const allInputs = root.querySelectorAll('[value="exclude"]:checked');
        
        let excludedCount = 0;
        let excludedItems = [];
        let noItemExcluded = false;
        
        // Univerzalno: input elementi uporabljajo data-filter-path (ne data-[type]-path)
        const pathAttribute = 'data-filter-path';
        
        allInputs.forEach(function(radio) {
            const itemPath = radio.getAttribute(pathAttribute);
            if (!itemPath) return;
            
            if (itemPath === noItemValue) {
                noItemExcluded = true;
            } else {
                excludedCount++;
                excludedItems.push(itemPath);
            }
        });
        
        // Dinamično sestavi dropdown text
        let dropdownText = '';
        // Univerzalno: sestavi množinsko obliko (samo dodaj 's')
        const itemTypePlural = itemType + 's';
        const itemTypeCapitalized = itemType.charAt(0).toUpperCase() + itemType.slice(1);
        const itemTypePluralCapitalized = itemTypePlural.charAt(0).toUpperCase() + itemTypePlural.slice(1);
        
        if (excludedCount === 0 && !noItemExcluded) {
            dropdownText = 'All ' + itemTypePluralCapitalized;
        } else if (excludedCount === 1 && !noItemExcluded) {
            dropdownText = '🚫 ' + excludedItems[0];
        } else if (excludedCount === 0 && noItemExcluded) {
            dropdownText = '🚫 No ' + itemTypeCapitalized;
        } else {
            const totalExcluded = excludedCount + (noItemExcluded ? 1 : 0);
            dropdownText = '🚫 ' + totalExcluded + ' ' + itemTypePlural + ' excluded';
        }
        
        // Poišči text element v root-u
        const dropdownTextElement = root.querySelector('.gp-filter-dropdown--text');
        if (dropdownTextElement) {
            dropdownTextElement.textContent = dropdownText;
        }
        
        // Univerzalno: posodobi included/excluded class-e za vse opcije
        // Poišči vse opcije z data atributom
        const allOptions = root.querySelectorAll('[' + dataAttribute + ']');
        
        allOptions.forEach(function(option) {
            const itemPath = option.getAttribute(dataAttribute);
            if (!itemPath) return;
            
            // Poišči input element za to opcijo (input elementi uporabljajo data-filter-path)
            const optionInputExclude = root.querySelector('input[data-filter-path="' + itemPath + '"][value="exclude"]');
            const optionInputInclude = root.querySelector('input[data-filter-path="' + itemPath + '"][value="include"]');
            
            const isExcluded = optionInputExclude && optionInputExclude.checked;
            const isIncluded = optionInputInclude && optionInputInclude.checked;
            
            // Odstrani oba class-a
            option.classList.remove('excluded', 'included');
            
            // Dodaj pravilen class
            if (isExcluded) {
                option.classList.add('excluded');
            } else if (isIncluded) {
                option.classList.add('included');
            }
        });
    }
    
    // Delegiran handler za spremembo radio button-ov
    document.addEventListener('change', function(e) {
        const target = e.target;
        
        // Preveri, ali je input znotraj dropdown root-a
        const root = target.closest('.gp-filter-dropdown--root');
        if (!root) return;
        
        // Preveri, ali je to filter dropdown input (univerzalno - katerikoli input znotraj dropdown-a)
        if (!target.matches('input[type="radio"]')) return;
        
        e.preventDefault();
        updateDropdownText(target);
    });
})();
// KONEC KODE: JavaScript za univerzalno posodabljanje dropdown teksta z delegiranimi event listenerji


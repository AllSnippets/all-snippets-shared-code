// ZAČETEK KODE: JavaScript za filter dropdown search funkcionalnost z delegiranimi event listenerji
(function() {
    // Začetek: delegiran search funkcionalnost za vse filter dropdown-e (tag, category, folder)
    document.addEventListener('input', function(e) {
        if (!e.target.matches('.gp-filter-dropdown--search')) return;
        
        const root = e.target.closest('.gp-filter-dropdown--root');
        if (!root) return;
        
        const searchTerm = e.target.value.toLowerCase();
        
        // Univerzalno: poišči prvi element s KATERIMKOLI data atributom
        // Poišči vse elemente v root-u in poišči prvega, ki ima data atribut
        const allElements = root.querySelectorAll('*');
        let firstOption = null;
        let dataAttribute = null;
        
        for (let i = 0; i < allElements.length; i++) {
            const element = allElements[i];
            // Preveri vse data atribute
            const attributes = element.attributes;
            for (let j = 0; j < attributes.length; j++) {
                const attr = attributes[j];
                if (attr.name.startsWith('data-') && attr.name !== 'data-plugin-slug' && attr.name !== 'data-page-slug' && attr.name !== 'data-admin-obj-name' && attr.name !== 'data-page-url') {
                    firstOption = element;
                    dataAttribute = attr.name;
                    break;
                }
            }
            if (firstOption) break;
        }
        
        if (!firstOption || !dataAttribute) {
            return;
        }
        
        // Iz data atributa izpelji tip (npr. data-tag -> tag, data-category -> category)
        const itemType = dataAttribute.replace('data-', '');
        
        // Poišči vse elemente z istim data atributom (ne glede na class)
        const options = root.querySelectorAll('[' + dataAttribute + ']');
        
        // Dinamično sestavi vrednosti za "No Item" opcijo
        const noItemValue = '__no_' + itemType + '__';
        const noItemText = 'no ' + itemType + ' snippets without ' + itemType;
        
        // Poišči scrollable container za prikaz sporočila "No results"
        const scrollableContainer = root.querySelector('.gp-filter-dropdown--scrollable');
        
        // Preveri, ali že obstaja "No results" sporočilo
        let noResultsMessage = root.querySelector('.gp-filter-dropdown--no-results');
        if (!noResultsMessage && scrollableContainer) {
            noResultsMessage = document.createElement('div');
            noResultsMessage.className = 'gp-filter-dropdown--no-results';
            noResultsMessage.style.cssText = 'padding: 12px; text-align: center; color: #666; font-size: 12px; display: none;';
            noResultsMessage.textContent = 'No results found';
            scrollableContainer.appendChild(noResultsMessage);
        }
        
        let visibleCount = 0;
        
        // Obdelaj vsako opcijo
        options.forEach(function(option) {
            const itemPath = option.getAttribute(dataAttribute);

            // Posebna obravnava za "No Item" opcijo (dinamično določeno)
            if (itemPath === noItemValue) {
                if (noItemText.indexOf(searchTerm) !== -1) {
                    option.style.display = '';
                    visibleCount++;
                } else {
                    option.style.display = 'none';
                }
                return;
            }

            // Univerzalno: poišči text element - poskusi različne selectors
            const optionText = option.querySelector('.gp-filter-dropdown--option-text') || 
            option.querySelector('span[style*="text-align: left"]') ||
            option.querySelector('span');
            const itemText = optionText ? optionText.textContent.toLowerCase() : '';
            
            if (itemText.indexOf(searchTerm) !== -1) {
                option.style.display = '';
                visibleCount++;
            } else {
                option.style.display = 'none';
            }
        });
        
        // Prikaži ali skrij "No results" sporočilo
        if (noResultsMessage) {
            if (searchTerm && visibleCount === 0) {
                noResultsMessage.style.display = 'block';
            } else {
                noResultsMessage.style.display = 'none';
            }
        }
    });
    // Konec: delegiran search funkcionalnost za vse filter dropdown-e
})();
// KONEC KODE: JavaScript za filter dropdown search funkcionalnost z delegiranimi event listenerji


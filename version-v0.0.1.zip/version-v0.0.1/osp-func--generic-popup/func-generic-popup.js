(function($) {
    'use strict';

    // Globalne spremenljivke za stanje
    var currentBtn = null;
    var currentPage = 1;
    var isLoading = false;

    // 1. ODPRE POPUP
    $(document).on('click', '.gp-generic-popup--trigger-btn', function(e) {
        e.preventDefault();
        
        currentBtn = $(this);
        currentPage = 1;
        isLoading = false;

        var popup = $('.gp-generic-popup--root');
        
        // Nastavi title iz data atributa
        var title = currentBtn.data('popup-title') || 'Details';
        popup.find('.gp-generic-popup--title').text(title);
        
        // Počisti vsebino in skrij footer
        popup.find('.gp-generic-popup--data-container').empty();
        popup.find('.gp-generic-popup--loading-body').addClass('gp-display-none');
        popup.find('.gp-generic-popup--footer').addClass('gp-display-none');
        
        // Prikaži popup
        popup.removeClass('gp-display-none');

        // Zaženi AJAX
        loadPopupData();
    });

    // 2. ZAPRE POPUP
    $(document).on('click', '.gp-generic-popup--close-btn', function() {
        $('.gp-generic-popup--root').addClass('gp-display-none');
    });

    // Zapiranje na klik overlay-a
    $(document).on('click', '.gp-generic-popup--root', function(e) {
        if (e.target === this) {
            $(this).addClass('gp-display-none');
        }
    });

    // 3. SHOW MORE (PAGINACIJA)
    $(document).on('click', '.gp-generic-popup--load-more-btn', function(e) {
        e.preventDefault();
        if (!isLoading) {
            currentPage++;
            loadPopupData();
        }
    });

    // 4. AJAX LOGIKA
    function loadPopupData() {
        if (!currentBtn) return;
        
        isLoading = true;
        var popup = $('.gp-generic-popup--root');
        
        // Prikaz loading stanja
        if (currentPage === 1) {
            popup.find('.gp-generic-popup--loading-body').removeClass('gp-display-none');
            popup.find('.gp-generic-popup--data-container').addClass('gp-display-none');
        } else {
            popup.find('.gp-generic-popup--load-more-btn').addClass('gp-display-none');
            popup.find('.gp-generic-popup--status').removeClass('gp-display-none');
        }

        // Pridobi globalni admin objekt preko shared configa
        if (!window.sharedPageConfig || !window.sharedPageConfig.adminObjName) {
            console.error('Shared page config missing');
            return;
        }
        var adminObj = window[window.sharedPageConfig.adminObjName];

        // Priprava podatkov
        var data = {
            action: currentBtn.data('popup-action'),
            nonce: adminObj.nonce,
            paged: currentPage,
            // Generično pošiljanje ID-ja (če obstaja)
            attachment_id: currentBtn.data('popup-attachment_id')
        };

        // Klic na strežnik
        $.post(adminObj.ajaxurl, data, function(response) {
            isLoading = false;
            
            // Skrij loading indikatorje
            popup.find('.gp-generic-popup--loading-body').addClass('gp-display-none');
            popup.find('.gp-generic-popup--data-container').removeClass('gp-display-none');

            if (response.success) {
                var res = response.data;
                var container = popup.find('.gp-generic-popup--data-container');
                
                // Prikaz vsebine
                if (currentPage === 1) {
                    container.html(res.html);
                } else {
                    // Append v obstoječo tabelo ali na konec
                    var tbody = container.find('tbody');
                    if (tbody.length) {
                        tbody.append(res.html);
                    } else {
                        container.append(res.html);
                    }
                }

                // Upravljanje Show More gumba
                var footer = popup.find('.gp-generic-popup--footer');
                if (res.has_more) {
                    footer.removeClass('gp-display-none');
                    footer.find('.gp-generic-popup--load-more-btn').removeClass('gp-display-none');
                    footer.find('.gp-generic-popup--status').addClass('gp-display-none');
                } else {
                    footer.addClass('gp-display-none');
                }
            } else {
                alert('Error loading data');
            }
        });
    }

})(jQuery);
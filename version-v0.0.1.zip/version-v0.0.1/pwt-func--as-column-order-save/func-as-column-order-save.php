<?php defined('WPINC') || die;
// ZAČETEK KODE: Shrani vrstni red stolpcev (skupna verzija za vse vtičnike)
// En handler za vse vtičnike - registrira se samo enkrat!

if (!has_action('wp_ajax_allsnippets_shared_func__save_column_order')) {
    add_action('wp_ajax_allsnippets_shared_func__save_column_order', function() {
        // Preberi plugin slug iz POST parametrov
        $plugin_slug = isset($_POST['plugin_slug']) ? sanitize_text_field($_POST['plugin_slug']) : '';
        if (empty($plugin_slug) || !preg_match('/^[a-z0-9\-]+$/', $plugin_slug)) {
            wp_send_json_error('Invalid plugin_slug.');
        }
        
        // Dinamično določi nonce constant (npr. 'all-broken-media' => 'ALL_BROKEN_MEDIA_NONCE_ADMIN')
        // Odstrani 'all-' na začetku, če obstaja, nato zamenjaj '-' z '_' in naredi uppercase
        $slug_for_constant = preg_replace('/^all-/', '', $plugin_slug);
        $nonce_constant_name = 'ALL_' . strtoupper(str_replace('-', '_', $slug_for_constant)) . '_NONCE_ADMIN';
        if (!defined($nonce_constant_name)) {
            wp_send_json_error('Nonce constant does not exist.');
        }
        $nonce_constant = constant($nonce_constant_name);
        
        // Dinamično določi helper funkcije (npr. 'all-broken-media' => 'all_broken_media__helper__userpref_get_data')
        $helper_get_data_func = str_replace('-', '_', $plugin_slug) . '__helper__userpref_get_data';
        $helper_save_data_func = str_replace('-', '_', $plugin_slug) . '__helper__userpref_save_data';
        
        if (!function_exists($helper_get_data_func) || !function_exists($helper_save_data_func)) {
            wp_send_json_error('Helper functions do not exist.');
        }
        
        // Preveri nonce
        check_ajax_referer($nonce_constant, 'nonce');
        
        // Preveri dostop
        if (!current_user_can('manage_options')) {
            wp_send_json_error('You do not have permission to perform this action.');
        }
        
        $user_id = get_current_user_id();
        
        // Preveri page_slug
        $page_slug = isset($_POST['page_slug']) ? sanitize_text_field($_POST['page_slug']) : '';
        if (empty($page_slug) || !preg_match('/^[a-z0-9\-_]+$/', $page_slug)) {
            wp_send_json_error('Invalid page_slug.');
        }
        
        // Pridobi obstoječe preference za to stran
        $user_preferences = call_user_func($helper_get_data_func, $user_id, $page_slug);
        if (!is_array($user_preferences)) {
            $user_preferences = [];
        }
        
        // Dodaj/posodobi column_order in column_widths
        $column_order = isset($_POST['column_order']) ? $_POST['column_order'] : [];
        $column_widths_raw = isset($_POST['column_widths']) ? $_POST['column_widths'] : [];
        
        // Sanitiziraj širine - samo številke (px)
        $column_widths = [];
        foreach ($column_widths_raw as $col => $width) {
            $column_widths[$col] = !empty($width) ? intval($width) : '';
        }
        
        $user_preferences['column_order'] = $column_order;
        $user_preferences['column_widths'] = $column_widths;
        
        // Shrani preference za to stran
        $save_result = call_user_func($helper_save_data_func, $user_id, $user_preferences, $page_slug);
        
        if ($save_result) {
            wp_send_json_success('Column order has been saved.');
        } else {
            wp_send_json_error('Error saving column order.');
        }
    });
}
// KONEC KODE: Shrani vrstni red stolpcev (skupna verzija za vse vtičnike)

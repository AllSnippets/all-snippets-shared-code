<?php defined('WPINC') || die;
add_action('admin_notices', 'all_snippets_shared__system_status_check');
// ZAČETEK KODE: Centraliziran sistem za preverjanje statusa vseh vtičnikov
if (!function_exists('all_snippets_shared__system_status_check')) {
    // Ta funkcija se izvede na 'admin_notices' hooku
    function all_snippets_shared__system_status_check() {
        // Če uporabnik nima pravic, ne kažemo ničesar
        if (!current_user_can('manage_options')) return;

        // Uporabimo globalni cache statusov
        global $all_snippets_status_cache;
        if (empty($all_snippets_status_cache) || !is_array($all_snippets_status_cache)) {
            return;
        }
        
        $issues_found = array();
        $trial_active = array();

        foreach ($all_snippets_status_cache as $plugin_slug => $status) {
            // Iz slug-a naredimo lepo ime (npr. all-broken-media -> All Broken Media)
            $display_name = ucwords(str_replace(['-', '_'], ' ', $plugin_slug));

            if ($status === 'nima' || $status === 'expired') {
                $issues_found[] = $display_name;
            } elseif ($status === 'proba') {
                $trial_active[] = $display_name;
            }
        }

        // Prikaz obvestil (uporabljamo nevtralne izraze)

        // 1. Kritična obvestila (manjkajoč cache/licenca)
        if (!empty($issues_found)) {
            ?>
            <div class="notice notice-error is-dismissible">
                <p><strong>System Alert:</strong> The following components require attention (Cache/Data Missing):</p>
                <ul style="list-style-type: disc; margin-left: 20px; margin-bottom: 10px;">
                    <?php foreach ($issues_found as $name): ?>
                        <li><strong><?php echo esc_html($name); ?></strong></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php
        }

        // 2. Obvestila o poskusnem obdobju (nevtralno)
        if (!empty($trial_active)) {
            ?>
            <div class="notice notice-warning is-dismissible">
                <p><strong>Maintenance Notice:</strong> The following components are running in Trial Mode:</p>
                <ul style="list-style-type: disc; margin-left: 20px; margin-bottom: 10px;">
                    <?php foreach ($trial_active as $name): ?>
                        <li><?php echo esc_html($name); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php
        }
    }
}
// KONEC KODE
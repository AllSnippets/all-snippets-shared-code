// ZAČETEK KODE: JavaScript za sidebar accordion toggle
// Script se naloži v footer (wp_enqueue_script zadnji parameter je true), zato DOM je že pripravljen
(function() {
    // Funkcija za inicializacijo
    function initSidebarAccordion() {
        // Poišči vse accordion elemente
        const accordions = document.querySelectorAll('.gp-sidebar--accordion');
        
        if (accordions.length === 0) {
            return; // Ni accordion elementov na strani
        }
        
        // Dodaj event listener za vsak accordion toggle gumb
        accordions.forEach(accordion => {
            // Toggle gumb je znotraj accordion elementa, zato uporabimo direktni selector
            const toggle = accordion.querySelector('.gp-sidebar--accordion--toggle');
            if (!toggle) return;
            
            // Nastavi začetno stanje (zaprto)
            accordion.setAttribute('aria-expanded', 'false');
            
            // Dodaj event listener
            toggle.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const isExpanded = accordion.getAttribute('aria-expanded') === 'true';
                
                // Toggle stanje
                accordion.setAttribute('aria-expanded', isExpanded ? 'false' : 'true');
                toggle.setAttribute('aria-expanded', isExpanded ? 'false' : 'true');
            });
        });
    }
    
    // Začni inicializacijo
    initSidebarAccordion();
})();
// KONEC KODE: JavaScript za sidebar accordion toggle


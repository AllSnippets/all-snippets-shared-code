<?php defined('WPINC') || die;
// ZAČETEK KODE: Čiščenje neuporabljenih verzij shared code datotek
// POMEMBNO: Ta funkcija preveri vse aktivne AllSnippets vtičnike in izbriše shared code datoteke z verzijami, ki jih noben aktivni vtičnik ne uporablja več
if (!function_exists('all_snippets__deactivation__delete_old_versions')) {
    // Dodamo parameter, da vemo, kateri vtičnik se deaktivira (in ga ne upoštevamo kot aktivnega)
    function all_snippets__deactivation__delete_old_versions($deactivating_plugin_file = null) {
        // Samo 1x na request
        static $checked = false;
        if ($checked) return;
        $checked = true;

        // Preveri, ali shared code mapa obstaja (uporabimo generično pot glede na wp-content/uploads)
        $upload_dir = wp_upload_dir();
        $shared_code_dir = $upload_dir['basedir'] . '/all-snippets-data/shared-code-load';
        
        if (!is_dir($shared_code_dir)) {
            return; // Če mapa ne obstaja, ni nič za čiščenje
        }
    
        // ZAČETEK: Zberi vse potrebne verzije iz aktivnih AllSnippets vtičnikov
        $required_versions = [];
        
        // Pridobi vse aktivne vtičnike
        $active_plugins = get_option('active_plugins', []);
        
        // Dodaj še network active plugine, če je multisite
        if (is_multisite()) {
            $network_active = get_site_option('active_sitewide_plugins');
            if (!empty($network_active)) {
                $active_plugins = array_merge($active_plugins, array_keys($network_active));
            }
        }

        // Odstrani vtičnik, ki se trenutno deaktivira, iz seznama aktivnih
        if ($deactivating_plugin_file) {
            $key = array_search($deactivating_plugin_file, $active_plugins);
            if ($key !== false) {
                unset($active_plugins[$key]);
            }
        }
        
        foreach ($active_plugins as $plugin_file) {
            // Dobimo mapo vtičnika
            $slug = dirname($plugin_file);

            // Preveri, ali je to AllSnippets vtičnik (začne se z "all-")
            if (strpos($slug, 'all-') === 0) {
                // Določi pot do glavne datoteke vtičnika
                // POZOR: Ponavadi je glavna datoteka enaka imenu mape, npr. all-broken-media/all-broken-media.php
                // Ampak ni nujno. WordPress shrani pot v $plugin_file.
                
                $plugin_path = WP_PLUGIN_DIR . '/' . $plugin_file;
                
                // Preveri, ali datoteka obstaja
                if (!file_exists($plugin_path)) {
                    continue;
                }
                
                // Preberi vsebino datoteke, da najdemo SHARED VERSION konstanto
                $plugin_content = file_get_contents($plugin_path);
                
                // Poišči konstanto ALL_[PLUGIN_NAME]__SHARED__VERSION
                // Vzorec: define('ALL_BROKEN_MEDIA__SHARED__VERSION', '0.0.1');
                if (preg_match("/define\s*\(\s*['\"]ALL_[A-Z_]+__SHARED__VERSION['\"]\s*,\s*['\"]([^'\"]+)['\"]\s*\)/", $plugin_content, $matches)) {
                    $version = $matches[1];
                    if (!in_array($version, $required_versions)) {
                        $required_versions[] = $version;
                    }
                }
            }
        }
        // KONEC: Zberi vse potrebne verzije iz aktivnih AllSnippets vtičnikov
        
        // OPOMBA: Če je $required_versions prazen, to pomeni, da ni nobenega aktivnega AllSnippets vtičnika več.
        // V tem primeru želimo IZBRISATI VSE verzije (tudi to, ki se trenutno izvaja).
        
        // ZAČETEK: Poišči vse verzijske mape v shared-code-load mapi
        $folders_to_check = [];
        $iterator = new DirectoryIterator($shared_code_dir);
        
        foreach ($iterator as $fileinfo) {
            if ($fileinfo->isDir() && !$fileinfo->isDot()) {
                $foldername = $fileinfo->getFilename();
                // Preveri, ali je mapa verzijska (vzorec: version-v0.0.1)
                if (preg_match('/^version-v(\d+\.\d+\.\d+)(\.[^.]+)?$/', $foldername, $matches)) {
                    $folder_version = $matches[1];
                    $folders_to_check[] = [
                        'path' => $fileinfo->getPathname(),
                        'version' => $folder_version,
                        'foldername' => $foldername
                    ];
                }
            }
        }
        // KONEC: Poišči vse verzijske mape v shared-code-load mapi
        
        // ZAČETEK: Izbriši mape z verzijami, ki niso potrebne
        foreach ($folders_to_check as $folder_data) {
            // Če verzija mape ni v seznamu potrebnih verzij, jo izbriši
            if (!in_array($folder_data['version'], $required_versions)) {
                // Rekurzivno brisanje mape
                $dir = $folder_data['path'];
                if (is_dir($dir)) {
                    // Poskusimo izbrisati. Uporabimo @ za utišanje napak (npr. na Windows, če je datoteka v uporabi)
                    $it = new RecursiveIteratorIterator(
                        new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS),
                        RecursiveIteratorIterator::CHILD_FIRST
                    );
                    
                    foreach ($it as $file) {
                        if ($file->isDir()) {
                            @rmdir($file->getPathname());
                        } else {
                            @unlink($file->getPathname());
                        }
                    }
                    @rmdir($dir);
                }
            }
        }
        // KONEC: Izbriši mape z verzijami, ki niso potrebne
    }
}
// KONEC KODE: Čiščenje neuporabljenih verzij shared code datotek
<?php defined('WPINC') || die;

// Shared Global Deactivation Listener
// This file is included by all "All Snippets" plugins.
// It listens for the 'deactivated_plugin' action and cleans up cache files
// for any "all-*" plugin that gets deactivated.

if (!function_exists('all_snippets_shared__global__on_deactivation')) {
    function all_snippets_shared__global__on_deactivation($plugin, $network_deactivating) {
        // $plugin is the path relative to plugins directory, e.g., 'all-broken-media/all-broken-media.php'
        
        $slug = dirname($plugin); // e.g., 'all-broken-media'
        
        // Only process our plugins (starting with 'all-')
        if (strpos($slug, 'all-') !== 0) {
            return;
        }

        // Define the cache directory based on the slug
        // Pattern: /wp-content/uploads/all-snippets-data/{slug}/cache/
        $uploads_dir = wp_upload_dir();
        $base_dir = $uploads_dir['basedir'] . '/all-snippets-data/';
        $cache_dir = $base_dir . $slug . '/cache/';
        
        // Check if cache directory exists
        if (file_exists($cache_dir) && is_dir($cache_dir)) {
            // Find and delete JSON cache files
            // Pattern: {slug}-cache-*.json
            // Example: all-broken-media-cache-*.json
            $pattern = $cache_dir . $slug . '-cache-*.json';
            $files = glob($pattern);
            
            if ($files) {
                foreach ($files as $file) {
                    @unlink($file);
                }
            }
        }
    }
}

// Register the hook
// This action fires after a plugin has been deactivated.
add_action('deactivated_plugin', 'all_snippets_shared__global__on_deactivation', 10, 2);

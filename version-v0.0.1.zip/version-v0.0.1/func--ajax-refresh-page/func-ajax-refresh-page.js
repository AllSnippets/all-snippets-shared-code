// ZAČETEK KODE: JavaScript za osvežitev tabele
// Script se naloži v footer (wp_enqueue_script zadnji parameter je true), zato DOM je že pripravljen
(function() {
    // Globalno dostopna funkcija za osvežitev tabele (kliče se iz func-save-userpref.js in drugih datotek)
    // Univerzalna funkcija za vse vtičnike - vedno bere podatke iz window.sharedPageConfig
    if (!window.allsnippetsAjaxRefreshPage) {
        window.allsnippetsAjaxRefreshPage = function() {
            // Preveri, če je sharedPageConfig na voljo
            if (!window.sharedPageConfig) {
                console.error('[AJAX REFRESH] window.sharedPageConfig is not defined');
                return;
            }
            
            // Vedno beri podatke iz window.sharedPageConfig (ne lokalnih spremenljivk)
            const { pluginSlug, adminObjName, pageUrl, pageSlug } = window.sharedPageConfig;
            
            if (!pageSlug) {
                console.error('[AJAX REFRESH] page slug is not defined');
                return;
            }
            
            if (!window[adminObjName]) {
                console.error('[AJAX REFRESH] Object', adminObjName, 'does not exist');
                return;
            }
            
            // Skupni action name za vse vtičnike (brez sufixa)
            const ajaxAction = 'all_snippets__ajax__refresh_page';
            
            // Funkcija za skrivanje/prikaz loading overlay-ja
            const setOverlayHidden = hidden => {
                const overlay = document.querySelector('.gp-loading--overlay');
                if (overlay) {
                    overlay.classList.toggle('hidden', hidden);
                }
            };
            
            // Helper funkciji za prikaz/skrivanje loading indikatorja
            const showLoadingIndicator = () => setOverlayHidden(false);
            const hideLoadingIndicator = () => setOverlayHidden(true);

            // AbortController za preklic prejšnjega AJAX klica (shranjen v window.sharedPageConfig)
            if (!window.sharedPageConfig.currentAbortController) {
                window.sharedPageConfig.currentAbortController = null;
            }
            
            // Prekliči prejšnji AJAX klic, če obstaja
            if (window.sharedPageConfig.currentAbortController) {
                window.sharedPageConfig.currentAbortController.abort();
                window.sharedPageConfig.currentAbortController = null;
            }

            showLoadingIndicator();
            
            // Pridobi trenutno stran - to je edini parameter, ki ga moramo poslati
            // Vse ostalo (filter, limit, sorting) PHP pridobi iz user preferences
            const table = document.querySelector('.gp-main-table--root');
            let paged = table && table.dataset.paged ? parseInt(table.dataset.paged) : 1;
            let retried = false; // Flag za preprečevanje neskončne zanke pri retry-ju

            // Notranja funkcija za AJAX zahtevo
            // Sprejme pagedToUse, ker se lahko spremeni med retry-jem
            function doAjax(pagedToUse) {
                // Prekliči prejšnji AJAX klic, če obstaja (tudi med retry-jem)
                if (window.sharedPageConfig.currentAbortController) {
                    window.sharedPageConfig.currentAbortController.abort();
                    window.sharedPageConfig.currentAbortController = null;
                }

                // Pripravi FormData za AJAX zahtevo
                // PHP pridobi filter, limit in sorting iz user preferences, zato jih ne pošiljamo
                const formData = new FormData();
                formData.append('action', ajaxAction);
                formData.append('nonce', window[adminObjName].nonce);
                formData.append('plugin_slug', pluginSlug);
                formData.append('page_slug', pageSlug);
                formData.append('paged', pagedToUse);
                
                // Ustvari nov AbortController za ta klic
                window.sharedPageConfig.currentAbortController = new AbortController();
                
                // PHP uporablja echo $html; wp_die() kar vrne HTML (ne JSON!)
                fetch(window[adminObjName].ajaxurl, {
                    method: 'POST',
                    body: formData,
                    signal: window.sharedPageConfig.currentAbortController.signal
                })
                .then(response => response.text())
                .then(htmlResponse => {
                    // Poišči element z class gp-main-view--root (vedno isti class, ne rabimo pluginSlug)
                    const pageViewZone = document.querySelector('.gp-main-view--root');
                    if (!pageViewZone) {
                        hideLoadingIndicator();
                        return;
                    }
                    
                    // Zamenjaj vsebino tabele z novo HTML vsebino
                    const parser = new DOMParser();
                    const parsedDocument = parser.parseFromString(htmlResponse, 'text/html');
                    const newPage = parsedDocument.querySelector('.gp-main-view--root');
                    
                    // Če najdemo wrapper v odgovoru, ga zamenjamo, sicer samo posodobimo innerHTML
                    if (newPage) {
                        pageViewZone.replaceWith(newPage);
                    } else {
                        pageViewZone.innerHTML = htmlResponse;
                    }
                    
                    // Sproži custom event za posodobitev tabele (uporabljajo ga lahko drugi skripti)
                    // Dinamično ime eventa na podlagi plugin slug-a
                    const eventName = `${pluginSlug.replace(/-/g, '')}TableRefreshed`;
                    setTimeout(() => document.dispatchEvent(new CustomEvent(eventName)), 50);
                    
                    // Preveri, če je trenutna stran večja od maksimalne (npr. če se je limit zmanjšal)
                    // Če je, ponovno naloži z zadnjo veljavno stranjo
                    const pagerSpan = document.querySelector('.gp-pagination--root span');
                    const maxPageText = pagerSpan ? pagerSpan.textContent : '';
                    const maxPageMatch = maxPageText.match(/of (\d+)/);
                    const maxPage = maxPageMatch ? parseInt(maxPageMatch[1]) : 1;
                    const currentTable = document.querySelector('.gp-main-table--root');
                    const currentPage = currentTable && currentTable.dataset.paged ? parseInt(currentTable.dataset.paged) : 1;
                    
                    // Retry logika: če smo na strani, ki ne obstaja več, naloži zadnjo veljavno stran
                    if (currentPage > maxPage && !retried) {
                        retried = true;
                        if (currentTable) {
                            currentTable.dataset.paged = maxPage;
                        }
                        doAjax(maxPage);
                        return;
                    }
                    
                    // Posodobi URL v browserju (brez reload-a strani)
                    // To omogoča, da se URL ujema s trenutno stranjo
                    const adminUrl = window.location.origin + '/wp-admin/admin.php';
                    const queryParams = new URLSearchParams();
                    queryParams.append('page', pageUrl);
                    const tableFinal = document.querySelector('.gp-main-table');
                    queryParams.append('paged', tableFinal && tableFinal.dataset.paged ? tableFinal.dataset.paged : '1');
                    window.history.pushState({}, '', adminUrl + '?' + queryParams.toString());
                    
                    hideLoadingIndicator();
                    window.sharedPageConfig.currentAbortController = null;
                })
                .catch(error => {
                    // Ignoriraj napake zaradi preklica
                    if (error.name !== 'AbortError') {
                        console.error('[AJAX REFRESH] Error:', error);
                    }
                    hideLoadingIndicator();
                    window.sharedPageConfig.currentAbortController = null;
                });
            }
            
            // Zaženi AJAX zahtevo z začetno stranjo
            doAjax(paged);
        };
    }
})();
// KONEC KODE: JavaScript za osvežitev tabele

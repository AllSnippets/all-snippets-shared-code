// ZAČETEK KODE: JavaScript za Reset Filters funkcionalnost z delegiranimi event listenerji
(function() {
    // Počakaj, da se sharedPageConfig naloži
    function initResetFilters() {
        if (!window.sharedPageConfig) {
            setTimeout(initResetFilters, 50);
            return;
        }
        
        const { pluginSlug, adminObjName, pageSlug, buildSelector } = window.sharedPageConfig;
        
        // Preveri, če objekt obstaja - če ne, počakaj malo in poskusi znova
        if (!window[adminObjName]) {
            // Počakaj 50ms in poskusi znova (maksimalno 20 poskusov = 1 sekunda)
            let attempts = 0;
            const maxAttempts = 20;
            const checkInterval = setInterval(() => {
                attempts++;
                if (window[adminObjName]) {
                    clearInterval(checkInterval);
                    continueInit();
                } else if (attempts >= maxAttempts) {
                    clearInterval(checkInterval);
                    console.error('[RESET FILTERS] Object', adminObjName, 'does not exist after', maxAttempts * 50, 'ms');
                }
            }, 50);
            return;
        }
        
        continueInit();
        
        function continueInit() {
            // Skupni action name za vse vtičnike
            const ajaxAction = 'allsnippets_shared_func__reset_filters';
            
            // Dinamično grajen selector za reset gumb
            const resetButtonSelector = buildSelector('.gp-filter-info--reset-button-small');
            
            // Delegiran event handler za "Resetiraj vse" gumb
            // Uporabimo capture fazo, da se izvede preden se event propagira do accordion toggle
            document.addEventListener('click', function(e) {
                const resetButton = e.target.closest(resetButtonSelector);
                if (!resetButton) return;
            
                // Prepreči propagacijo eventa (da se ne odpre accordion)
                e.stopPropagation();
                e.stopImmediatePropagation();
                e.preventDefault();
            
                if (confirm('Are you sure you want to reset all filters and settings?')) {
                    
                    // Prikaži loading
                    const originalContent = resetButton.innerHTML;
                    resetButton.innerHTML = '<span class="dashicons dashicons-update" style="animation: spin 1s linear infinite;"></span>';
                    resetButton.style.pointerEvents = 'none';
                    resetButton.style.opacity = '0.6';
                    
                    // Pripravi FormData za fetch poziv
                    const formData = new FormData();
                    formData.append('action', ajaxAction);
                    formData.append('nonce', window[adminObjName].nonce);
                    formData.append('user_id', window[adminObjName].user_id);
                    formData.append('plugin_slug', pluginSlug);
                    formData.append('page_slug', pageSlug);
                    
                    // Fetch poziv za reset
                    fetch(window[adminObjName].ajaxurl, {
                        method: 'POST',
                        body: formData,
                        credentials: 'same-origin'
                    })
                    .then(res => res.json())
                    .then(response => {
                        if (response.success) {
                            // Osveži stran za popoln reset
                            window.location.reload();
                        } else {
                            alert('Error resetting filters: ' + (response.data || 'Unknown error'));
                            resetButton.innerHTML = originalContent;
                            resetButton.style.pointerEvents = '';
                            resetButton.style.opacity = '';
                        }
                    })
                    .catch(error => {
                        console.error('[RESET FILTERS] Error:', error);
                        alert('Error resetting filters.');
                        resetButton.innerHTML = originalContent;
                        resetButton.style.pointerEvents = '';
                        resetButton.style.opacity = '';
                    });
                }
            }, true); // capture: true - izvede se preden se event propagira
        }
    }
    
    initResetFilters();
})();
// KONEC KODE: JavaScript za Reset Filters funkcionalnost z delegiranimi event listenerji


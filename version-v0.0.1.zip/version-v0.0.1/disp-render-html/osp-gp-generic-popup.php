<?php defined('WPINC') || die; ?>
<div class="gp-generic-popup--root gp-display-none">
    <div class="gp-generic-popup--content">
        <h2 class="gp-generic-popup--title"></h2>
        <div class="gp-generic-popup--subtitle"></div>
        
        <div class="gp-generic-popup--body">
            <div class="gp-generic-popup--loading-body gp-display-none">Loading...</div>
            <div class="gp-generic-popup--data-container"></div>
        </div>

        <div class="gp-generic-popup--footer gp-display-none">
            <button class="gp-generic-popup--load-more-btn gp-button gp-button--secondary">
                Show More
            </button>
            <div class="gp-generic-popup--status gp-display-none">Loading...</div>
        </div>
        
        <button class="gp-generic-popup--close-btn gp-button gp-button--secondary">
            X
        </button>
    </div>
</div>

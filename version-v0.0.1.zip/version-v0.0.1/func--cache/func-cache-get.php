<?php defined('WPINC') || die;
if (!function_exists('all_snippets_shared__cache__update_all_caches')) {
    // Ta funkcija se kliče samo, ko je ugotovljeno, da cache manjka ali je potekel
    function all_snippets_shared__cache__update_all_caches() {
        // 1. Identificiraj vse aktivne "All Snippets" vtičnike
        // Iščemo konstante, ki se končajo na _CACHE_SLUG in začnejo z ALL_
        $plugins_map = []; // slug => cache_json_base_path
        $all_constants = get_defined_constants(true);
        
        if (isset($all_constants['user'])) {
            foreach ($all_constants['user'] as $name => $value) {
                // Primer: ALL_DB_TABLES_CACHE_SLUG => 'all-db-tables'
                if (strpos($name, '_CACHE_SLUG') !== false && strpos($name, 'ALL_') === 0) {
                    // Dobimo prefix, npr. ALL_DB_TABLES iz ALL_DB_TABLES_CACHE_SLUG
                    $prefix = substr($name, 0, -11); 
                    
                    // Sestavimo ime konstante za JSON pot: ALL_DB_TABLES__DATABASE__CACHE_JSON
                    // Uporabnica zahteva preverjanje te specifične konstante
                    $json_const = $prefix . '__DATABASE__CACHE_JSON';
                    
                    if (defined($json_const)) {
                        $path_value = constant($json_const);
                        // Shranimo pot (ki je ponavadi base path za datoteko, npr. .../cache-file-)
                        $plugins_map[$value] = $path_value;
                    }
                }
            }
        }

        if (empty($plugins_map)) {
            return;
        }

        // 2. Pripravi podatke za API klic
        $domain = isset($_SERVER['HTTP_HOST']) ? strtolower($_SERVER['HTTP_HOST']) : 'unknown';
        $site_id = function_exists('get_current_blog_id') ? get_current_blog_id() : 1;
        $plugins_list = array_keys($plugins_map);

        // 3. Pošlji BATCH request na API
        $response = wp_remote_post('https://allsnippets.com/wp-json/allsnippets/v1/check-cache', array(
            'timeout' => 15,
            'blocking' => true, // Mora počakati na odgovor
            'body' => array(
                'plugins' => $plugins_list, // Pošljemo array slugov
                'domain' => $domain,
                'site_id' => $site_id,
            )
        ));

        if (is_wp_error($response)) {
            // Log error if needed
            error_log('All Snippets Cache Update Failed: ' . $response->get_error_message());
            return;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        // 4. Obdelaj rezultate in shrani v datoteke
        if (is_array($data) && isset($data['batch_results'])) {
            $clean_domain = preg_replace('/[^a-z0-9\-]+/', '-', str_replace('.', '-', $domain));
            
            foreach ($data['batch_results'] as $slug => $result) {
                // Preveri, če imamo mapo za ta slug in če je rezultat validen
                if (isset($plugins_map[$slug]) && is_array($result) && isset($result['s'], $result['e'])) {
                    $cache_base_path = $plugins_map[$slug];
                    
                    // Sestavimo polno pot do datoteke
                    // $cache_base_path je npr. ".../uploads/all-broken-media-data/cache/all-broken-media-cache-"
                    $file_path = $cache_base_path . $clean_domain . '-' . $site_id . '.json';
                    
                    // Zagotovi, da mapa obstaja
                    $dir_path = dirname($file_path);
                    if (!is_dir($dir_path)) {
                        wp_mkdir_p($dir_path);
                    }
                    
                    // Shrani JSON (povozi starega)
                    file_put_contents($file_path, json_encode($result));
                }
            }
        }
    }
}
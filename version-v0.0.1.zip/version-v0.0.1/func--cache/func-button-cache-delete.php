<?php defined('WPINC') || die;
// ZAČETEK KODE: Univerzalni handler za brisanje cache-a
add_action('admin_post_all_snippets_delete_cache', 'all_snippets__func__delete_cache');
if (!function_exists('all_snippets_shared__func__delete_cache')) {
    function all_snippets_shared__func__delete_cache() {
        // 1. Pridobi slug vtičnika iz URL parametra
        $plugin_slug = isset($_GET['plugin_slug']) ? sanitize_text_field($_GET['plugin_slug']) : '';
        
        if (empty($plugin_slug)) {
            wp_die('Missing plugin slug.');
        }

        // 2. Dinamično poišči konstante na podlagi sluga
        // Pretvorimo slug (npr. 'all-broken-media') v prefix konstante (npr. 'ALL_BROKEN_MEDIA')
        $const_prefix = strtoupper(str_replace('-', '_', $plugin_slug));
        
        // Imena potrebnih konstant
        $nonce_const = $const_prefix . '_NONCE_DELETE_CACHE';
        // Preveri različne variacije za cache path (JSON ali DIR)
        $cache_path_const = defined($const_prefix . '__DATABASE__CACHE_DIR') 
            ? $const_prefix . '__DATABASE__CACHE_DIR' 
            : $const_prefix . '__DATABASE__CACHE_JSON';
            
        $redirect_page_const = $const_prefix . '_ADMIN_MNG';

        // 3. Varnostno preverjanje: ali konstante sploh obstajajo?
        if (!defined($nonce_const) || !defined($cache_path_const) || !defined($redirect_page_const)) {
            wp_die('Invalid plugin configuration or unknown plugin.');
        }

        // 4. Preveri nonce
        // Uporabimo vrednost konstante za preverjanje
        if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], constant($nonce_const))) {
            wp_die('Security check failed (Nonce).');
        }

        // 5. Sestavi pot do datoteke
        $site_id = function_exists('get_current_blog_id') ? get_current_blog_id() : 1;
        $domain = isset($_SERVER['HTTP_HOST']) ? strtolower($_SERVER['HTTP_HOST']) : 'unknown';
        $clean_domain = preg_replace('/[^a-z0-9\-]+/', '-', str_replace('.', '-', $domain));
        
        // Pridobi pot iz konstante
        $base_path = constant($cache_path_const);
        $cache_file = $base_path . $clean_domain . '-' . $site_id . '.json';

        // 6. Izbriši datoteko
        if (file_exists($cache_file)) {
            @unlink($cache_file);
        }

        // 7. Preusmeri nazaj
        // Pridobi URL stran iz konstante
        $page_slug = constant($redirect_page_const);
        wp_redirect(admin_url('admin.php?page=' . $page_slug));
        exit;
    }
}
// KONEC KODE
<?php defined('WPINC') || die;
if (!function_exists('all_snippets_shared__register_rest_delete_cache')) {
    function all_snippets_shared__register_rest_delete_cache($plugin_slug) {
        register_rest_route($plugin_slug . '/v1', '/delete-cache', array(
            'methods' => 'POST',
            'callback' => function($request) use ($plugin_slug) {
                // 1. Dinamično poišči konstante na podlagi sluga
                $const_prefix = strtoupper(str_replace('-', '_', $plugin_slug));
                
                // Preveri različne variacije za cache path (JSON ali DIR)
                // Uporabljamo enako logiko kot v func-button-cache-delete.php
                $cache_path_const = defined($const_prefix . '__DATABASE__CACHE_DIR') 
                    ? $const_prefix . '__DATABASE__CACHE_DIR' 
                    : $const_prefix . '__DATABASE__CACHE_JSON';
                
                if (!defined($cache_path_const)) {
                     return new WP_REST_Response(['status' => 'error', 'message' => 'Configuration not found'], 500);
                }
                
                $base_path = constant($cache_path_const);
                
                // 2. Pridobi podatke za sestavo imena datoteke
                $domain = isset($_SERVER['HTTP_HOST']) ? strtolower($_SERVER['HTTP_HOST']) : 'unknown';
                $clean_domain = preg_replace('/[^a-z0-9\-]+/', '-', str_replace('.', '-', $domain));
                
                // Pridobi site_id iz parametrov ali uporabi trenutnega
                $site_id = $request->get_param('site_id');
                if (!$site_id) {
                    $site_id = function_exists('get_current_blog_id') ? get_current_blog_id() : 1;
                }
                
                $cache_file = $base_path . $clean_domain . '-' . $site_id . '.json';
                
                // 3. Izbriši datoteko
                // Vrnemo success tudi če datoteka ne obstaja (idempotentnost)
                if (file_exists($cache_file)) {
                    @unlink($cache_file);
                }
                
                return ['status' => 'success'];
            },
            'permission_callback' => function() { return current_user_can('manage_options'); },
        ));
    }
}

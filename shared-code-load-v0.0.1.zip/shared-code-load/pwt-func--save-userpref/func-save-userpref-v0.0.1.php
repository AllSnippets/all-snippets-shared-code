<?php defined('WPINC') || die;
// ZAČETEK KODE: Shranjevanje uporabniških nastavitev
add_action('wp_ajax_allsnippets__ajax__save_userpref_admin_page', 'allsnippets__func__save_userpref_admin_page');

function allsnippets__func__save_userpref_admin_page() {
    // Začetek: Preverjanje uporabniških pravic
    if (!current_user_can('manage_options')) {
        wp_send_json_error('[SAVE USERPREF] You do not have permission to perform this action.');
    }
    // Konec: Preverjanje uporabniških pravic

    // Začetek: Preverjanje potrebnih podatkov
    if (!isset($_POST['user_id']) || !isset($_POST['user_preferences']) || !isset($_POST['plugin_slug']) || !isset($_POST['page_slug'])) {
        wp_send_json_error('[SAVE USERPREF] Missing required data.');
    }
    // Konec: Preverjanje potrebnih podatkov

    // Začetek: Priprava podatkov
    $user_id = intval($_POST['user_id']);
    $plugin_slug = sanitize_text_field($_POST['plugin_slug']);
    $page_slug = sanitize_text_field($_POST['page_slug']);
    
    // Dinamično določi nonce konstanto na podlagi plugin_slug
    $nonce_constant = strtoupper(str_replace('-', '_', $plugin_slug)) . '_NONCE_ADMIN';
    if (!defined($nonce_constant)) {
        wp_send_json_error('[SAVE USERPREF] Nonce constant is not defined for plugin: ' . $plugin_slug);
    }
    
    // Začetek: Preverjanje nonce
    check_ajax_referer(constant($nonce_constant), 'nonce');
    // Konec: Preverjanje nonce
    
    // Dinamično določi helper funkcije na podlagi plugin_slug
    $helper_get_func = str_replace('-', '_', $plugin_slug) . '__helper__userpref_get_data';
    $helper_save_func = str_replace('-', '_', $plugin_slug) . '__helper__userpref_save_data';
    
    if (!function_exists($helper_get_func) || !function_exists($helper_save_func)) {
        wp_send_json_error('[SAVE USERPREF] Helper functions are not available for plugin: ' . $plugin_slug);
    }
    
    // Pridobi obstoječe preference
    $existing_preferences = call_user_func($helper_get_func, $user_id, $page_slug);
    if (!is_array($existing_preferences)) {
        $existing_preferences = [];
    }
    
    $new_preferences = $_POST['user_preferences'];
    
    // Sanitizacija podatkov in združitev z obstoječimi
    $user_preferences = $existing_preferences; // Ohrani obstoječe (vključno z column_order in column_widths)
    
    // Limit
    $user_preferences['limit'] = isset($new_preferences['limit']) ? intval($new_preferences['limit']) : (isset($existing_preferences['limit']) ? $existing_preferences['limit'] : 20);
    
    // Sorting
    $user_preferences['orderby'] = isset($new_preferences['orderby']) ? sanitize_text_field($new_preferences['orderby']) : (isset($existing_preferences['orderby']) ? $existing_preferences['orderby'] : '');
    $user_preferences['order'] = isset($new_preferences['order']) ? sanitize_text_field($new_preferences['order']) : (isset($existing_preferences['order']) ? $existing_preferences['order'] : 'DESC');
    
    // Columns
    if (isset($new_preferences['columns'])) {
        $user_preferences['columns'] = array_map('sanitize_text_field', $new_preferences['columns']);
    } elseif (isset($existing_preferences['columns'])) {
        $user_preferences['columns'] = $existing_preferences['columns'];
    }
    
    // Table visibility (za all-site-views in all-db-terms)
    if (isset($new_preferences['tables'])) {
        $user_preferences['tables'] = array_map('sanitize_text_field', $new_preferences['tables']);
    } elseif (isset($existing_preferences['tables'])) {
        $user_preferences['tables'] = $existing_preferences['tables'];
    }
    
    // Dinamično obravnava vseh filter polj
    // Preveri vse možne filter ključe iz POST podatkov
    $possible_filter_keys = [
        'filter', 'filter_user_type', 'filter_type', 'filter_status', 'filter_essential',
        'filter_attachment', 'filter_active', 'filter_global', 'filter_user_role',
        'filter_tag', 'filter_category', 'filter_folder', 'filter_scope', 'filter_code_type'
    ];
    
    foreach ($possible_filter_keys as $filter_key) {
        if (isset($new_preferences[$filter_key])) {
            // Preveri, če je filter array (toggle/dropdown) ali string (radio)
            if (is_array($new_preferences[$filter_key])) {
                // Toggle ali dropdown filter - sanitiziraj vsak element
                $sanitized_filter = [];
                foreach ($new_preferences[$filter_key] as $filter_path => $mode) {
                    $sanitized_filter[sanitize_text_field($filter_path)] = sanitize_text_field($mode);
                }
                $user_preferences[$filter_key] = $sanitized_filter;
            } else {
                // Radio filter - enostavna string vrednost
                $user_preferences[$filter_key] = sanitize_text_field($new_preferences[$filter_key]);
            }
        } elseif (isset($existing_preferences[$filter_key])) {
            // Ohrani obstoječo vrednost, če ni v novih podatkih
            $user_preferences[$filter_key] = $existing_preferences[$filter_key];
        }
    }
    
    // Konec: Priprava podatkov

    // Začetek: Shranjevanje nastavitev
    $save_result = call_user_func($helper_save_func, $user_id, $user_preferences, $page_slug);
    if ($save_result) {
        wp_send_json_success('[SAVE USERPREF] Settings have been successfully saved.');
    } else {
        wp_send_json_error('[SAVE USERPREF] Error: Settings could not be saved.');
    }
    // Konec: Shranjevanje nastavitev
}
// KONEC KODE: Shranjevanje uporabniških nastavitev


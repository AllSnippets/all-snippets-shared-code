<?php defined('WPINC') || die;
if (!has_action('wp_ajax_allsnippets__ajax__refresh_page')) {
    add_action('wp_ajax_allsnippets__ajax__refresh_page', function() {
        $plugin_slug = isset($_POST['plugin_slug']) ? sanitize_text_field($_POST['plugin_slug']) : '';
        $page_slug = isset($_POST['page_slug']) ? sanitize_text_field($_POST['page_slug']) : '';
        
        $slug_for_constant = preg_replace('/^all-/', '', $plugin_slug);
        $nonce_constant_name = 'ALL_' . strtoupper(str_replace('-', '_', $slug_for_constant)) . '_NONCE_ADMIN';
        if (!defined($nonce_constant_name)) {
            wp_send_json_error('Nonce constant does not exist.');
        }
        $nonce_constant = constant($nonce_constant_name);
        
        check_ajax_referer($nonce_constant, 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('You do not have permission to perform this action.');
        }

        foreach ($_POST as $key => $value) {
            $_GET[$key] = $value;
        }

        $html = call_user_func('allsnippets__display__pg_' . $page_slug, true);
        echo $html;
        wp_die();
    });
}
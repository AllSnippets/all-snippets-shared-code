// ZAČETEK KODE: Shared funkcionalnost za View More/Less toggle v tabelah
// Verzija: v0.0.1
(function() {
    // Počakaj na konfiguracijo
    function init() {
        if (!window.sharedPageConfig) {
            setTimeout(init, 50);
            return;
        }

        const { pluginSlug } = window.sharedPageConfig;

        // Glavna funkcija za preverjanje višine in prikaz gumbov
        function checkHeightsAndToggleButtons() {
            const wrappers = document.querySelectorAll('.gp-td-prev-height--root');
            
            wrappers.forEach(wrapper => {
                const container = wrapper.querySelector('.gp-td-prev-height--max-height');
                // Poskusi najti gumb
                let button = wrapper.querySelector('.gp-td-prev-height--view-more-btn');

                if (container && button) {
                    // Preveri, če vsebina presega max-height
                    if (container.scrollHeight > container.clientHeight) {
                        button.classList.remove('gp-display-none');
                    } else {
                        // Če je vsebina manjša, skrij gumb, razen če je že razširjen (uporabnik kliknil View More)
                        if (!container.classList.contains('gp-max-height-none')) {
                            button.classList.add('gp-display-none');
                        }
                    }
                }
            });
        }

        // Event listener za klike
        document.addEventListener('click', function(e) {
            // Preveri, če je kliknjen element gumb za view more
            // Iščemo class, ki vsebuje "view-more-btn"
            const target = e.target;
            
            // Preveri ali je target ali njegov starš gumb
            let button = target.closest('.gp-td-prev-height--view-more-btn');
            
            // Dodatno preverjanje: mora biti znotraj našega root wrapperja
            if (!button || !button.closest('.gp-td-prev-height--root')) {
                return;
            }

            const wrapper = button.closest('.gp-td-prev-height--root');
            const container = wrapper.querySelector('.gp-td-prev-height--max-height');

            if (!container) return;

            const isExpanded = container.classList.contains('gp-max-height-none');

            if (!isExpanded) {
                // Razširi
                container.classList.add('gp-max-height-none');
                button.textContent = 'View Less';
            } else {
                // Skrči
                container.classList.remove('gp-max-height-none');
                button.textContent = 'View More';
            }
        });

        // Zaženi ob nalaganju
        checkHeightsAndToggleButtons();

        // Izpostavi funkcijo globalno, da jo lahko pokličemo po AJAX reloadu
        window.allsnippetsCheckViewMoreHeights = checkHeightsAndToggleButtons;
        
        // Poslušaj za custom evente, če obstajajo (za re-init po ajaxu)
        // Opcijsko: če uporabljamo standardni event za refresh
        // const refreshEventName = `${pluginSlug.replace(/-/g, '')}AjaxRefreshDone`;
        // document.addEventListener(refreshEventName, checkHeightsAndToggleButtons);
    }

    init();
})();
// KONEC KODE: Shared funkcionalnost za View More/Less toggle v tabelah

// ZAČETEK KODE: Minimalistična AJAX paginacija v tvojem stilu
// Script se naloži v footer (wp_enqueue_script zadnji parameter je true), zato DOM je že pripravljen
(function() {
    // Funkcija za inicializacijo - počaka, da se objekt lokalizira
    function initAjaxReloadGenerateUrl() {
        // Počakaj, da se sharedPageConfig naloži (iz func-get-page-config.js)
        if (!window.sharedPageConfig) {
            setTimeout(initAjaxReloadGenerateUrl, 50);
            return;
        }
        
        const { pluginSlug, adminObjName, pageUrl, pageSlug } = window.sharedPageConfig;
        
        // Preveri, če objekt obstaja - če ne, počakaj malo in poskusi znova
        if (!window[adminObjName]) {
            // Počakaj 50ms in poskusi znova (maksimalno 20 poskusov = 1 sekunda)
            let attempts = 0;
            const maxAttempts = 20;
            const checkInterval = setInterval(() => {
                attempts++;
                if (window[adminObjName]) {
                    clearInterval(checkInterval);
                    continueInit();
                } else if (attempts >= maxAttempts) {
                    clearInterval(checkInterval);
                    console.error('[AJAX RELOAD] Object', adminObjName, 'does not exist after', maxAttempts * 50, 'ms');
                }
            }, 50);
            return;
        }
        
        continueInit();
        
        function continueInit() {
            if (!pageSlug) {
                console.error('[AJAX RELOAD] page slug is not defined');
                return;
            }
            
            // Skupni action name za vse vtičnike (brez sufixa)
            const ajaxAction = 'allsnippets__ajax__refresh_page';
            
            // Funkcija za skrivanje/prikaz loading overlay-ja
            const setOverlayHidden = hidden => {
                const overlay = document.querySelector('.gp-loading--overlay');
                if (overlay) {
                    overlay.classList.toggle('hidden', hidden);
                }
            };
            
            // Helper funkciji za prikaz/skrivanje loading indikatorja
            const showLoadingIndicator = () => setOverlayHidden(false);
            const hideLoadingIndicator = () => setOverlayHidden(true);
            hideLoadingIndicator();

            // Listener za puščice (delegiran)
            document.addEventListener('click', function(e) {
                const ajaxLink = e.target.closest('.gp-pagination--arrow-link, .gp-pagination--page-number-link');
                if (!ajaxLink) return;
                
                const href = ajaxLink.getAttribute('href');
                if (!href || href === '#' || href.indexOf('page=' + pageUrl) === -1) return;
                e.preventDefault();
                handlePagination(href);
            });
            
            // Funkcije za prikaz/skritje validacijskega obvestila
            const notice = () => document.querySelector('.gp-pagination--goto-validation-notice');
            const showNotice = () => {
                const n = notice();
                if (n) n.classList.remove('hidden');
            };
            const hideNotice = () => {
                const n = notice();
                if (n) n.classList.add('hidden');
            };
            
            // Listener za spremembo vrednosti inputa
            document.addEventListener('input', function(e) {
                if (e.target.matches('.gp-pagination--goto-input')) {
                    hideNotice();
                }
            });
            
            // Listener za ročni vnos (klik na Go button)
            document.addEventListener('click', function(e) {
                const goButton = e.target.closest('.gp-pagination--goto-btn');
                if (!goButton) return;
                
                e.preventDefault();
                const pagedInput = document.querySelector('.gp-pagination--goto-input');
                if (!pagedInput) return;
                
                if (!pagedInput.checkValidity()) {
                    showNotice();
                    return;
                }
                
                hideNotice();
                const pagedValue = pagedInput.value || '1';
                const href = window.location.origin + '/wp-admin/admin.php?page=' + pageUrl + '&paged=' + pagedValue;
                handlePagination(href);
            });

            // Vse v eni funkciji: AJAX, update URL, loading inline
            function handlePagination(source) {
                const data = {};
                
                // Pripravi parametre iz source (href)
                if (typeof source === 'string') {
                    const urlParams = new URLSearchParams(source.split('?')[1]);
                    urlParams.forEach(function(value, key) {
                        if (key !== 'action' && key !== 'nonce') data[key] = value;
                    });
                }

                // Dopolni manjkajoče parametre iz data atributa tabele
                if (!data.paged) {
                    const table = document.querySelector('.wp-list-table.widefat');
                    if (table && table.dataset.paged) {
                        data.paged = table.dataset.paged;
                    }
                }

                // Doda action, nonce, plugin_slug in page_slug
                data.action = ajaxAction;
                data.nonce = window[adminObjName].nonce;
                data.plugin_slug = pluginSlug;
                data.page_slug = pageSlug;

                // Prikaže loading
                showLoadingIndicator();

                // Pošlje AJAX zahtevek
                // PHP uporablja echo $html; wp_die() kar vrne HTML (ne JSON!)
                const formData = new FormData();
                for (const key in data) {
                    formData.append(key, data[key]);
                }
                
                fetch(window[adminObjName].ajaxurl, {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.text())
                .then(htmlResponse => {
                    // Parse HTML iz odgovora
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(htmlResponse, 'text/html');
                    const newWrap = doc.querySelector('.gp-main-view--root');
                    
                    // Poišči element z class gp-main-view--root (vedno isti class, ne rabimo pluginSlug)
                    const pageViewZone = document.querySelector('.gp-main-view--root');
                    if (newWrap && pageViewZone) {
                        pageViewZone.replaceWith(newWrap);
                    }

                    // Sproži custom event za posodobitev tabele
                    // Dinamično ime eventa na podlagi plugin slug-a
                    const eventName = `${pluginSlug.replace(/-/g, '')}TableRefreshed`;
                    setTimeout(() => document.dispatchEvent(new CustomEvent(eventName)), 50);

                    // Posodobi URL
                    const adminUrl = window.location.origin + '/wp-admin/admin.php';
                    const queryParams = new URLSearchParams();
                    queryParams.append('page', pageUrl);
                    if (data.paged) queryParams.append('paged', data.paged);
                    window.history.pushState({}, '', adminUrl + '?' + queryParams.toString());
                    
                    hideLoadingIndicator();
                })
                .catch(error => {
                    console.error('[AJAX RELOAD] Error:', error);
                    hideLoadingIndicator();
                });
            }
        }
    }
    
    // Začni inicializacijo (funkcija že počaka na window.sharedPageConfig in window[adminObjName])
    initAjaxReloadGenerateUrl();
})();
// KONEC KODE: Minimalistična AJAX paginacija v tvojem stilu


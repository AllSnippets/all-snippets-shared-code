<?php defined('WPINC') || die;
// ZAČETEK KODE: Reset Filters funkcionalnost
// Skupni action name za vse vtičnike
if (!has_action('wp_ajax_allsnippets_shared_func__reset_filters')) {
    add_action('wp_ajax_allsnippets_shared_func__reset_filters', function() {
        // Začetek: Preverjanje uporabniških pravic
        if (!current_user_can('manage_options')) {
            wp_send_json_error('You do not have permission to perform this action.');
        }
        // Konec: Preverjanje uporabniških pravic

        // Začetek: Preverjanje potrebnih podatkov
        if (!isset($_POST['user_id']) || !isset($_POST['plugin_slug']) || !isset($_POST['page_slug'])) {
            wp_send_json_error('Missing required data.');
        }
        // Konec: Preverjanje potrebnih podatkov

        // Začetek: Priprava podatkov
        $user_id = intval($_POST['user_id']);
        $plugin_slug = sanitize_text_field($_POST['plugin_slug']);
        $page_slug = sanitize_text_field($_POST['page_slug']);
        
        // Dinamično določi nonce konstanto na podlagi plugin_slug
        $slug_for_constant = preg_replace('/^all-/', '', $plugin_slug);
        $nonce_constant_name = 'ALL_' . strtoupper(str_replace('-', '_', $slug_for_constant)) . '_NONCE_ADMIN';
        if (!defined($nonce_constant_name)) {
            wp_send_json_error('Nonce constant is not defined for plugin: ' . $plugin_slug);
        }
        
        // Začetek: Preverjanje nonce
        check_ajax_referer(constant($nonce_constant_name), 'nonce');
        // Konec: Preverjanje nonce
        
        // Dinamično določi konstante za userpref datoteko na podlagi plugin_slug
        $slug_for_constant_clean = str_replace('-', '_', $plugin_slug);
        $userpref_dir_constant = strtoupper($slug_for_constant_clean) . '__DATABASE__USERPREF_DIR';
        $userpref_prefix_constant = strtoupper($slug_for_constant_clean) . '__DATABASE__USERPREF_JSON_PREFIX';
        
        if (!defined($userpref_dir_constant) || !defined($userpref_prefix_constant)) {
            wp_send_json_error('Userpref constants are not defined for plugin: ' . $plugin_slug);
        }
        
        // Začetek: Reset userpref
        // Izbriši datoteko z userpref
        $file_path = constant($userpref_dir_constant) . 'pg-' . $page_slug . '/' . constant($userpref_prefix_constant) . intval($user_id) . '.json';
        
        if (file_exists($file_path)) {
            unlink($file_path);
        }
        
        wp_send_json_success('All filters and settings have been successfully reset.');
        // Konec: Reset userpref
    });
}
// KONEC KODE: Reset Filters funkcionalnost


// ZAČETEK KODE: Globalni helper za pridobivanje konfiguracijskih podatkov iz data atributov
// Ta skript se naloži prvi in shrani konfiguracijo v window.sharedPageConfig
(function() {
    // Preveri, če je že inicializiran
    if (window.sharedPageConfig) {
        return;
    }

    function initializeSharedPageConfig() {
        // Poišči element z class gp-main-view--root (na njemu so vsi data atributi)
        const datasetElement = document.querySelector('.gp-main-view--root');
        if (!datasetElement) {
            // Če ni datasetElement, počakaj malo in poskusi znova (morda se še naloži)
            setTimeout(initializeSharedPageConfig, 100);
            return;
        }
        
        // Seznam atributov, ki jih moramo prebrati iz data atributov elementa
        const allAttributes = [
            { key: 'pluginSlug', attr: 'pluginSlug', error: 'data-plugin-slug' },
            { key: 'pageSlug', attr: 'pageSlug', error: 'data-page-slug' },
            { key: 'adminObjName', attr: 'adminObjName', error: 'data-admin-obj-name' },
            { key: 'pageUrl', attr: 'pageUrl', error: 'data-page-url' }
        ];
        
        const config = {};
        let hasError = false;
        
        // Preberi vse atribute iz elementa in jih shrani v config objekt
        for (const { key, attr, error } of allAttributes) {
            const value = datasetElement.dataset[attr];
            if (!value) {
                console.error(`[SHARED CONFIG] ${error} atribut je prazen`);
                hasError = true;
                break;
            }
            config[key] = value;
        }

        if (hasError) {
            return;
        }
        
        // Helper funkcija za gradnjo CSS selectorjev
        // Primer: buildSelector('.gp-filter-info--reset-button-small') -> '.all-snipcode.pg-sniplistab.gp-filter-info--reset-button-small'
        function buildSelector(suffix) {
            // Odstranimo začetno piko, če obstaja
            const cleanSuffix = suffix.startsWith('.') ? suffix.slice(1) : suffix;
            // Gradimo selector: pluginSlug + pageSlug (z 'pg-' prefixom) + suffix
            return `.${config.pluginSlug}.pg-${config.pageSlug}.${cleanSuffix}`;
        }
        
        window.sharedPageConfig = {
            ...config,
            buildSelector: buildSelector
        };
    }

    // Zaženi inicializacijo (funkcija že počaka, če element ni najden)
    initializeSharedPageConfig();
})();
// KONEC KODE: Globalni helper za pridobivanje konfiguracijskih podatkov iz data atributov


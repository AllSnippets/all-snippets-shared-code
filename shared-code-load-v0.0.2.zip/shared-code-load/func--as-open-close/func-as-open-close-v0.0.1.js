// ZAČETEK KODE: Advanced Settings popup z delegiranimi event listenerji
// Dinamična koda, ki deluje za vse vtičnike
(function() {
    // Odpri popup - delegiran listener za delovanje po AJAX refresh-u
    document.addEventListener('click', function(e) {
        const btn = e.target.closest('.gp-top-bar--advanced-settings-btn');
        if (!btn) return;
        
        e.preventDefault();
        
        const popup = document.querySelector('.gp-advset--root');
        const overlay = document.querySelector('.gp-sidebar--overlay');
        
        if (popup) {
            popup.classList.add('is-open');
            popup.classList.remove('closing');
        }
        if (overlay) {
            overlay.classList.add('is-visible');
        }
    });
    
    // Zapri popup - delegiran listener za delovanje po AJAX refresh-u
    document.addEventListener('click', function(e) {
        const closeBtn = e.target.closest('.gp-advset--close');
        if (!closeBtn) return;
        
        const popup = document.querySelector('.gp-advset--root');
        const overlay = document.querySelector('.gp-sidebar--overlay');
        
        if (popup) {
            popup.classList.add('closing');
            popup.classList.remove('is-open');
        }
        if (overlay) {
            overlay.classList.remove('is-visible');
        }
    });
    
    // Zapri popup s klikom na overlay
    document.addEventListener('click', function(e) {
        const overlay = e.target.closest('.gp-sidebar--overlay');
        if (!overlay) return;
        
        const popup = document.querySelector('.gp-advset--root');
        if (popup && popup.classList.contains('is-open')) {
            popup.classList.add('closing');
            popup.classList.remove('is-open');
            overlay.classList.remove('is-visible');
        }
    });
    
    // Zapri popup ob pritisku ESC
    document.addEventListener('keydown', function(e) {
        if (e.key !== 'Escape') return;
        
        const popup = document.querySelector('.gp-advset--root');
        if (popup && popup.classList.contains('is-open')) {
            const overlay = document.querySelector('.gp-sidebar--overlay');
            popup.classList.add('closing');
            popup.classList.remove('is-open');
            if (overlay) {
                overlay.classList.remove('is-visible');
            }
        }
    });
})();
// KONEC KODE: Advanced Settings popup z delegiranimi event listenerji

// ZAČETEK KODE: JavaScript za detect plugins z AJAX in refresh
// Script se naloži v footer (wp_enqueue_script zadnji parameter je true), zato DOM je že pripravljen
(function() {
    'use strict';

    // Helper funkcija za klic univerzalne funkcije za osvežitev tabele
    // Uporabljamo window.allsnippetsAjaxRefreshPage, ki je definirana v shared kodi
    function callAjaxRefreshPage() {
        if (typeof window.allsnippetsAjaxRefreshPage === 'function') {
            window.allsnippetsAjaxRefreshPage();
        } else {
            console.error('[DETECT PLUGINS] window.allsnippetsAjaxRefreshPage function does not exist');
        }
    }

    // Helper funkcije za loading indicator
    // Uporabljamo obstoječi overlay v DOM-u (.gp-loading--overlay)
    const setOverlayHidden = hidden => {
        const overlay = document.querySelector('.gp-loading--overlay');
        if (overlay) {
            overlay.classList.toggle('hidden', hidden);
        }
    };
    const showLoadingIndicator = () => setOverlayHidden(false);
    const hideLoadingIndicator = () => setOverlayHidden(true);

    // Event listener za detect plugins gumb
    document.addEventListener('click', function(e) {
        const detectButton = e.target.closest('.gp-detect-plugins-btn');
        if (!detectButton) return;
        
        e.preventDefault();
        
        // Preveri sharedPageConfig
        if (!window.sharedPageConfig) {
            console.error('[DETECT PLUGINS] window.sharedPageConfig is not defined');
            return;
        }

        const { pluginSlug, adminObjName } = window.sharedPageConfig;
        
        // Preveri admin objekt
        if (!window[adminObjName]) {
            console.error('[DETECT PLUGINS] Admin object', adminObjName, 'does not exist');
            return;
        }

        // Prikaži loading overlay
        showLoadingIndicator();
        
        // Dinamično zgradi ime akcije: plugin-slug -> plugin_slug__ajax__detect_plugins
        // Zamenjamo pomišljaje z podčrtaji (npr. all-db-usermeta -> all_db_usermeta)
        const actionSlug = pluginSlug.replace(/-/g, '_');
        const actionName = `${actionSlug}__ajax__detect_plugins`;

        // Pripravi podatke
        const formData = new FormData();
        formData.append('action', actionName);
        formData.append('nonce', window[adminObjName].nonce);
        
        // Izvedi klic
        fetch(window[adminObjName].ajaxurl, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(response => {
            if (response.success) {
                // Skrij loading preden kličemo refresh (ki ima lahko svoj loading logic)
                hideLoadingIndicator();
                callAjaxRefreshPage();
            } else {
                hideLoadingIndicator();
                console.error('Detect error:', response.data || 'Unknown error');
            }
        })
        .catch(error => {
            hideLoadingIndicator();
            console.error('AJAX error:', error);
        });
    });
})();
// KONEC KODE: JavaScript za detect plugins z AJAX in refresh

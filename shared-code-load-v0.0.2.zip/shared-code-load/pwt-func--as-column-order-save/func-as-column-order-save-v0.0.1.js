// ZAČETEK KODE: JavaScript za shranjevanje vrstnega reda stolpcev
(function() {
    const dragInitialized = {};
    
    // Funkcija za inicializacijo - počaka, da se objekt lokalizira
    function initColumnOrderSave() {
        // Počakaj, da se sharedPageConfig naloži (iz func-get-page-config.js)
        if (!window.sharedPageConfig) {
            setTimeout(initColumnOrderSave, 50);
            return;
        }
        
        const { pluginSlug, adminObjName } = window.sharedPageConfig;
        
        // Preveri, če objekt obstaja - če ne, počakaj malo in poskusi znova
        if (!window[adminObjName]) {
            // Počakaj 50ms in poskusi znova (maksimalno 20 poskusov = 1 sekunda)
            let attempts = 0;
            const maxAttempts = 20;
            const checkInterval = setInterval(() => {
                attempts++;
                if (window[adminObjName]) {
                    clearInterval(checkInterval);
                    continueInit();
                } else if (attempts >= maxAttempts) {
                    clearInterval(checkInterval);
                    console.error('[COLUMN ORDER SAVE] Object', adminObjName, 'does not exist after', maxAttempts * 50, 'ms');
                }
            }, 50);
            return;
        }
        
        continueInit();
        
        function continueInit() {
            document.addEventListener('change', function(e) {
                const widthInput = e.target.closest('.gp-advset--column-order--width-input');
                if (widthInput) {
                    // Poišči page slug iz data-page-slug atributa na reset buttonu ali iz najbližjega accordion-a
                    const resetBtn = widthInput.closest('.gp-advset--column-order--wrapper').querySelector('.gp-advset--column-order--reset-btn');
                    const pageSlug = resetBtn ? resetBtn.getAttribute('data-page-slug') : null;
                    if (pageSlug) {
                        saveColumnOrderSilent(pageSlug);
                    }
                }
            });

            document.addEventListener('click', function(e) {
                const title = e.target.closest('.gp-advset--accordion-title');
                if (!title) return;

                if (title.textContent.includes('Column Order')) {
                    setTimeout(function() {
                        // Poišči vse column order liste (generični selector)
                        const columnOrderLists = document.querySelectorAll('.gp-advset--column-order--list');
                        columnOrderLists.forEach(function(list) {
                            // Poišči page slug iz reset buttona v istem wrapper-ju
                            const wrapper = list.closest('.gp-advset--column-order--wrapper');
                            const resetBtn = wrapper ? wrapper.querySelector('.gp-advset--column-order--reset-btn') : null;
                            const pageSlug = resetBtn ? resetBtn.getAttribute('data-page-slug') : null;
                            if (pageSlug) {
                                initDragAndDrop(pageSlug);
                            }
                        });
                    }, 300);
                }
            });

            function initDragAndDrop(pageSlug) {
                // Poišči list za ta page slug
                const resetBtn = document.querySelector('.gp-advset--column-order--reset-btn[data-page-slug="' + pageSlug + '"]');
                if (!resetBtn) return;
                
                const wrapper = resetBtn.closest('.gp-advset--column-order--wrapper');
                if (!wrapper) return;
                
                const list = wrapper.querySelector('.gp-advset--column-order--list');
                if (!list) return;

                if (dragInitialized[pageSlug]) {
                    return;
                }

                const items = list.querySelectorAll('.gp-advset--column-order--item');
                items.forEach(item => item.setAttribute('draggable', 'true'));

                let draggedItem = null;

                list.addEventListener('dragstart', function(e) {
                    const item = e.target.closest('.gp-advset--column-order--item');
                    if (!item) return;
                    draggedItem = item;
                    item.classList.add('dragging');
                    e.dataTransfer.effectAllowed = 'move';
                    e.dataTransfer.setData('text/plain', '');
                });

                list.addEventListener('dragover', function(e) {
                    if (!draggedItem) return;
                    e.preventDefault();
                    const item = e.target.closest('.gp-advset--column-order--item');
                    if (!item || item === draggedItem) return;

                    const rect = item.getBoundingClientRect();
                    const isAfter = (e.clientY - rect.top) > rect.height / 2;
                    if (isAfter) {
                        item.after(draggedItem);
                    } else {
                        item.before(draggedItem);
                    }
                });

                list.addEventListener('drop', function(e) {
                    e.preventDefault();
                });

                list.addEventListener('dragend', function() {
                    if (draggedItem) {
                        draggedItem.classList.remove('dragging');
                        draggedItem = null;
                        saveColumnOrderSilent(pageSlug);
                    }
                });

                dragInitialized[pageSlug] = true;
            }

            // AbortController za preklic prejšnjega AJAX klica
            let currentAbortController = null;

            function saveColumnOrderSilent(pageSlug) {
                // Prekliči prejšnji AJAX klic, če obstaja
                if (currentAbortController) {
                    currentAbortController.abort();
                    currentAbortController = null;
                }

                // Poišči wrapper za ta page slug
                const resetBtn = document.querySelector('.gp-advset--column-order--reset-btn[data-page-slug="' + pageSlug + '"]');
                if (!resetBtn) return;
                
                const wrapper = resetBtn.closest('.gp-advset--column-order--wrapper');
                if (!wrapper) return;
                
                const list = wrapper.querySelector('.gp-advset--column-order--list');
                if (!list) return;

                const columnOrder = [];
                list.querySelectorAll('.gp-advset--column-order--item').forEach(function(item) {
                    if (item.dataset.column) {
                        columnOrder.push(item.dataset.column);
                    }
                });

                const columnWidths = {};
                list.querySelectorAll('.gp-advset--column-order--item').forEach(function(item) {
                    const col = item.dataset.column;
                    if (!col) return;
                    const valueInput = item.querySelector('.gp-advset--column-order--width-input');
                    if (valueInput && valueInput.value) {
                        columnWidths[col] = parseInt(valueInput.value) || '';
                    }
                });

                // Skupni action name za vse vtičnike
                const actionName = 'allsnippets_shared_func__save_column_order';

                const formData = new FormData();
                formData.append('action', actionName);
                formData.append('plugin_slug', pluginSlug);
                formData.append('nonce', window[adminObjName].nonce);
                formData.append('page_slug', pageSlug);

                columnOrder.forEach(col => {
                    formData.append('column_order[]', col);
                });

                Object.keys(columnWidths).forEach(col => {
                    formData.append(`column_widths[${col}]`, columnWidths[col]);
                });

                // Ustvari nov AbortController za ta klic (shrani v lokalno spremenljivko)
                const abortController = new AbortController();
                // Nastavi na currentAbortController šele ko začnemo fetch
                currentAbortController = abortController;

                fetch(window[adminObjName].ajaxurl, {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin',
                    signal: abortController.signal
                })
                .then(response => response.json())
                .then(resp => {
                    // Preveri, ali je še vedno aktiven (ni bil preklican)
                    if (currentAbortController === abortController) {
                        if (resp && resp.success) {
                            // Osveži stran, da se prikaže privzeti vrstni red
                            if (typeof window.allsnippetsAjaxRefreshPage === 'function') {
                                window.allsnippetsAjaxRefreshPage();
                            }
                        } else if (resp && resp.data) {
                            console.error('Error saving column order:', resp.data);
                        }
                        currentAbortController = null;
                    }
                })
                .catch(error => {
                    // Ignoriraj napake zaradi preklica
                    if (error.name !== 'AbortError') {
                        console.error('Error saving column order:', error);
                    }
                    // Preveri, ali je še vedno aktiven (ni bil preklican)
                    if (currentAbortController === abortController) {
                        currentAbortController = null;
                    }
                });
            }
        }
    }
    
    // Začni inicializacijo (funkcija že počaka na window.sharedPageConfig in window[adminObjName])
    initColumnOrderSave();
})();
// KONEC KODE: JavaScript za shranjevanje vrstnega reda stolpcev

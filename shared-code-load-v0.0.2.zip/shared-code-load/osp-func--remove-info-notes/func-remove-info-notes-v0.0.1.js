// ZAČETEK KODE: Skupna JavaScript funkcija za brisanje info_notes z AJAX refresh
(function() {
    // Preverimo, ali obstaja konfiguracija
    if (!window.sharedPageConfig) {
        console.error('[REMOVE INFO NOTES] window.sharedPageConfig object is missing.');
        return;
    }

    // Destrukturiramo potrebne podatke
    const { pluginSlug, funcName } = window.sharedPageConfig;

    // Helper funkcija za klic osveževanja strani
    function callAjaxRefreshPage() {
        const refreshFuncName = `${funcName}-ajaxRefreshPage`;
        if (typeof window[refreshFuncName] === 'function') {
            window[refreshFuncName]();
        } else {
            console.error('[REMOVE INFO NOTES] Function', refreshFuncName, 'does not exist.');
        }
    }

    // Event listener za gumb
    document.addEventListener('click', function(e) {
        const button = e.target.closest('.gp-delete-all-info-notes-btn');
        if (!button) return;
        
        e.preventDefault();
        
        if (!confirm('Are you sure you want to delete ALL info_notes values? This action cannot be undone!')) {
            return;
        }

        // Pokaži loading overlay
        const loadingOverlay = document.querySelector('.gp-loading--overlay');
        if (loadingOverlay) {
            loadingOverlay.classList.remove('gp-display-none');
        }

        // Določi ime akcije
        const action = `${pluginSlug}__ajax__delete_all_info_notes`;

        // Pridobi ajaxurl iz lokaliziranega objekta
        const adminObjName = `${funcName}Admin`;
        const adminObj = window[adminObjName];
        
        if (!adminObj || !adminObj.ajaxurl) {
            console.error(`[REMOVE INFO NOTES] Object ${adminObjName} or ajaxurl is missing.`);
            if (loadingOverlay) loadingOverlay.classList.add('gp-display-none');
            return;
        }

        const formData = new FormData();
        formData.append('action', action);

        fetch(adminObj.ajaxurl, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(response => {
            // Skrij loading overlay (razen če refresh funkcija tega ne zahteva drugače)
            if (loadingOverlay) loadingOverlay.classList.add('gp-display-none');

            if (response.success) {
                callAjaxRefreshPage();
            } else {
                console.error('Delete error:', response.data);
                alert('Error deleting info_notes values: ' + (response.data && response.data.message ? response.data.message : 'Unknown error'));
            }
        })
        .catch(error => {
            if (loadingOverlay) loadingOverlay.classList.add('gp-display-none');
            console.error('AJAX error:', error);
            alert('An error occurred while connecting.');
        });
    });

})();
// KONEC KODE: Skupna JavaScript funkcija za brisanje info_notes z AJAX refresh

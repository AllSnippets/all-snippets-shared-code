(function() {
    // Počakaj da se naloži
    document.addEventListener('DOMContentLoaded', function() {
        const menuItems = document.querySelectorAll('#adminmenu li.wp-has-submenu');
        
        menuItems.forEach(menuItem => {
            const submenu = menuItem.querySelector('.wp-submenu');
            if (!submenu) return;
            
            // Ko je hover nad menijem
            menuItem.addEventListener('mouseenter', function() {
                const rect = this.getBoundingClientRect();
                
                // Odstrani WordPressove skrivalne stile
                submenu.style.cssText = '';
                
                // Nastavi fixed pozicijo
                submenu.style.cssText = `
                    position: fixed !important;
                    left: ${rect.left + rect.width}px !important;
                    top: ${rect.top}px !important;
                    display: block !important;
                    opacity: 1 !important;
                    visibility: visible !important;
                    z-index: 99999 !important;
                `;
            });
            
            // Ko miška zapusti
            menuItem.addEventListener('mouseleave', function() {
                submenu.style.display = 'none';
            });
        });
        
        // Ob scrollu popravi pozicijo vseh prikazanih submenijev
        window.addEventListener('scroll', function() {
            document.querySelectorAll('.wp-submenu[style*="position: fixed"]').forEach(submenu => {
                const menuItem = submenu.closest('li.wp-has-submenu');
                if (menuItem && menuItem.matches(':hover')) {
                    const rect = menuItem.getBoundingClientRect();
                    submenu.style.left = (rect.left + rect.width) + 'px !important';
                    submenu.style.top = rect.top + 'px !important';
                }
            });
        });
    });
})();
// ZAČETEK KODE: JavaScript za zanesljivo shranjevanje filtrov, limita in stolpcev
// Script se naloži v footer (wp_enqueue_script zadnji parameter je true), zato DOM je že pripravljen
(function() {
    'use strict';
    
    // Počakaj, da se window.sharedPageConfig naloži (naloži se preko func-get-page-config.js)
    function init() {
        if (!window.sharedPageConfig) {
            setTimeout(init, 50);
            return;
        }
        
        // window.sharedPageConfig je na voljo, nadaljuj z inicializacijo
    
    // Helper funkcija za klic univerzalne funkcije za osvežitev tabele
    function callAjaxRefreshPage() {
        if (typeof window.allsnippetsAjaxRefreshPage === 'function') {
            window.allsnippetsAjaxRefreshPage();
        } else {
            console.error('[SAVE USERPREF] Function allsnippetsAjaxRefreshPage does not exist');
        }
    }
    
    // Globalne spremenljivke za sledenje vrednosti
    let currentLimitValue = '';
    
    // Debouncing za shranjevanje nastavitev
    let saveTimeout = null;
    let currentSaveController = null; // AbortController za preklic prejšnjih zahtev
    
    // Loading overlay selector
    const loadingOverlaySelector = '.gp-loading--overlay';
    const setOverlayHidden = hidden => {
        const overlay = document.querySelector(loadingOverlaySelector);
        if (overlay) {
            overlay.classList.toggle('hidden', hidden);
        }
    };
    const showLoadingIndicator = () => setOverlayHidden(false);
    const hideLoadingIndicator = () => setOverlayHidden(true);
    hideLoadingIndicator();
    
    // Inicializacija currentLimitValue
    const limitInputSelector = '.gp-pagination--limit-input';
    const limitInput = document.querySelector(limitInputSelector);
    if (limitInput) {
        currentLimitValue = limitInput.value;
    }

    // Delegiran handler za spremembo limita
    document.addEventListener('input', function(e) {
        if (e.target.matches(limitInputSelector)) {
            currentLimitValue = e.target.value;
        }
    });

    // Delegiran handler za klik na Apply button za limit
    document.addEventListener('click', function(e) {
        const limitButtonSelector = '.gp-pagination--limit-btn';
        const limitButton = e.target.closest(limitButtonSelector);
        if (!limitButton) return;
        
        e.preventDefault();
        e.stopPropagation();
        const limitWrapSelector = '.gp-pagination--limit-wrap';
        const limitForm = limitButton.closest(limitWrapSelector);
        const limitInput = limitForm ? limitForm.querySelector(limitInputSelector) : null;
        if (limitInput) {
            currentLimitValue = limitInput.value;
        }
        showLoadingIndicator();
        save_user_preferences().then(function() {
            callAjaxRefreshPage();
        }).catch(function(error) {
            console.error('[SAVE USERPREF LIMIT] Error:', error);
            hideLoadingIndicator();
        });
    });

    // Delegiran handler za Enter key na limit input
    document.addEventListener('keydown', function(e) {
        if (e.target.matches(limitInputSelector) && e.key === 'Enter') {
            e.preventDefault();
            e.stopPropagation();
            currentLimitValue = e.target.value;
            showLoadingIndicator();
            save_user_preferences().then(function() {
                callAjaxRefreshPage();
            }).catch(function(error) {
                console.error('[SAVE USERPREF LIMIT ENTER] Error:', error);
                hideLoadingIndicator();
            });
        }
    });

    // Delegiran handler za spremembo filter-radio
    document.addEventListener('change', function(e) {
        const filterRadioSelector = '.gp-filter-radio--input';
        if (e.target.matches(filterRadioSelector)) {
            e.preventDefault();
            showLoadingIndicator();
            save_user_preferences().then(function() {
                callAjaxRefreshPage();
            }).catch(function(error) {
                console.error('[SAVE USERPREF FILTER RADIO] Error:', error);
                hideLoadingIndicator();
            });
        }
    });

    // Delegiran handler za spremembo filter-toggle
    document.addEventListener('change', function(e) {
        const filterToggleSelector = '.gp-filter-toggle--input';
        if (e.target.matches(filterToggleSelector)) {
            e.preventDefault();
            showLoadingIndicator();
            save_user_preferences().then(function() {
                callAjaxRefreshPage();
            }).catch(function(error) {
                console.error('[SAVE USERPREF FILTER TOGGLE] Error:', error);
                hideLoadingIndicator();
            });
        }
    });

    // Delegiran handler za spremembo filter-dropdown
    document.addEventListener('change', function(e) {
        const filterDropdownSelector = '.gp-filter-dropdown--input';
        if (e.target.matches(filterDropdownSelector)) {
            e.preventDefault();
            showLoadingIndicator();
            save_user_preferences().then(function() {
                callAjaxRefreshPage();
            }).catch(function(error) {
                console.error('[SAVE USERPREF FILTER DROPDOWN] Error:', error);
                hideLoadingIndicator();
            });
        }
    });

    // Delegiran handler za spremembo stolpcev (checkboxi)
    document.addEventListener('change', function(e) {
        const columnCheckboxSelector = '.gp-column-selection--checkbox';
        if (e.target.matches(columnCheckboxSelector)) {
            const checkbox = e.target;
            const column = checkbox.dataset.column;
            if (column) {
                const colSelector = 'th[data-column="' + column + '"], td[data-column="' + column + '"]';
                const columnElements = document.querySelectorAll(colSelector);
                
                if (checkbox.checked) {
                    columnElements.forEach(el => el.style.display = '');
                } else {
                    columnElements.forEach(el => el.style.display = 'none');
                }
            }
            
            // Debounced shranjevanje - počakaj 300ms, preden pošlješ AJAX
            if (saveTimeout) {
                clearTimeout(saveTimeout);
            }
            
            // Prekliči prejšnjo zahtevo, če še teče
            if (currentSaveController) {
                currentSaveController.abort();
            }
            
            saveTimeout = setTimeout(function() {
                save_user_preferences();
            }, 300);
        }
    });

    // Delegiran handler za spremembo table visibility (checkboxi)
    document.addEventListener('change', function(e) {
        const tableCheckboxSelector = '.gp-table-selection--checkbox';
        if (e.target.matches(tableCheckboxSelector)) {
            const checkbox = e.target;
            const table = checkbox.dataset.table;
            if (table) {
                const tableSelector = '[data-table="' + table + '"]';
                const tableElement = document.querySelector(tableSelector);
                
                if (checkbox.checked) {
                    if (tableElement) tableElement.style.display = '';
                } else {
                    if (tableElement) tableElement.style.display = 'none';
                }
            }
            
            // Debounced shranjevanje
            if (saveTimeout) {
                clearTimeout(saveTimeout);
            }
            
            if (currentSaveController) {
                currentSaveController.abort();
            }
            
            saveTimeout = setTimeout(function() {
                save_user_preferences();
            }, 300);
        }
    });

    // Delegiran handler za klik na sorting linke
    document.addEventListener('click', function(e) {
        const sortingLinkSelector = '.gp-main-table--sorting-link';
        const sortingLink = e.target.closest(sortingLinkSelector);
        if (!sortingLink) return;
        
        e.preventDefault();
        showLoadingIndicator();
        
        const href = sortingLink.getAttribute('href');
        if (!href) {
            hideLoadingIndicator();
            return;
        }
        
        // Parsi URL parametre
        const urlParams = new URLSearchParams(href.split('?')[1]);
        const orderby = urlParams.get('orderby');
        const order = urlParams.get('order');
        
        if (orderby && order) {
            // Normaliziraj order vrednost (asc/desc -> ASC/DESC)
            const normalizedOrder = order.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';
            // Shrani v user preferences in osveži tabelo
            save_user_preferences(orderby, normalizedOrder).then(function() {
                callAjaxRefreshPage();
            }).catch(function(error) {
                console.error('[SAVE USERPREF SORTING] Error:', error);
                hideLoadingIndicator();
            });
        } else {
            hideLoadingIndicator();
        }
    });

    // Funkcija za pridobitev trenutnih sorting vrednosti iz data atributov tabele
    function getCurrentSorting() {
        const table = document.querySelector('.wp-list-table');
        if (!table) {
            return { orderby: '', order: 'DESC' };
        }
        
        const orderby = table.getAttribute('data-current-orderby');
        const order = table.getAttribute('data-current-order');
        
        return {
            orderby: orderby || '',
            order: order || 'DESC'
        };
    }

    // Funkcija za zbiranje filter-radio podatkov
    function getFilterRadioData() {
        const filterData = {};
        const filterRadioSelector = '.gp-filter-radio--input';
        document.querySelectorAll(filterRadioSelector + ':checked').forEach(function(input) {
            const filterKey = input.dataset.filterKey;
            if (filterKey) {
                filterData[filterKey] = input.value;
            }
        });
        return filterData;
    }

    // Funkcija za zbiranje filter-toggle podatkov
    function getFilterToggleData() {
        const filterData = {};
        const filterToggleSelector = '.gp-filter-toggle--input';
        document.querySelectorAll(filterToggleSelector + ':checked').forEach(function(input) {
            const filterKey = input.dataset.filterKey;
            const filterPath = input.dataset.filterPath;
            if (filterKey && filterPath) {
                if (!filterData[filterKey]) {
                    filterData[filterKey] = {};
                }
                filterData[filterKey][filterPath] = input.value; // 'include' ali 'exclude'
            }
        });
        return filterData;
    }

    // Funkcija za zbiranje filter-dropdown podatkov
    function getFilterDropdownData() {
        const filterData = {};
        const filterDropdownSelector = '.gp-filter-dropdown--input';
        document.querySelectorAll(filterDropdownSelector + ':checked').forEach(function(input) {
            const filterKey = input.dataset.filterKey;
            const filterPath = input.dataset.filterPath;
            if (filterKey && filterPath) {
                if (!filterData[filterKey]) {
                    filterData[filterKey] = {};
                }
                filterData[filterKey][filterPath] = input.value; // 'include' ali 'exclude'
            }
        });
        return filterData;
    }

    // Funkcija za zbiranje column podatkov
    function getColumnData() {
        const columns = [];
        const columnCheckboxSelector = '.gp-column-selection--checkbox';
        
        // Checked checkboxes
        document.querySelectorAll(columnCheckboxSelector + ':checked').forEach(function(checkbox) {
            const column_name = checkbox.dataset.column;
            if (column_name) {
                columns.push(column_name);
            }
        });
        
        // Unchecked checkboxes
        document.querySelectorAll(columnCheckboxSelector + ':not(:checked)').forEach(function(checkbox) {
            const column_name = checkbox.dataset.column;
            if (column_name) {
                columns.push(column_name + ':off');
            }
        });
        
        return columns;
    }

    // Funkcija za zbiranje table visibility podatkov
    function getTableVisibilityData() {
        const tables = [];
        const tableCheckboxSelector = '.gp-table-selection--checkbox';
        
        document.querySelectorAll(tableCheckboxSelector).forEach(function(checkbox) {
            const table_name = checkbox.dataset.table;
            if (table_name) {
                if (checkbox.checked) {
                    tables.push(table_name);
                } else {
                    tables.push(table_name + ':off');
                }
            }
        });
        
        return tables;
    }

    // Funkcija za shranjevanje (sprejme opcijske parametre orderby in order)
    function save_user_preferences(orderby, order) {
        return new Promise(function(resolve, reject) {
            // Ustvari nov AbortController za to zahtevo
            currentSaveController = new AbortController();
            const signal = currentSaveController.signal;
            
            // Pridobi podatke iz window.sharedPageConfig (ne iz DOM-a)
            const { pluginSlug, pageSlug, adminObjName } = window.sharedPageConfig;
            
            // Pridobi limit vrednost
            const limitInput = document.querySelector(limitInputSelector);
            const limitToSave = currentLimitValue || (limitInput ? limitInput.value : '');
            
            // Pridobi sorting vrednosti - uporabi podane parametre ali trenutne vrednosti
            const sorting = (orderby && order) ? { orderby: orderby, order: order } : getCurrentSorting();
            
            // Pridobi vse filter podatke
            const filterRadioData = getFilterRadioData();
            const filterToggleData = getFilterToggleData();
            const filterDropdownData = getFilterDropdownData();
            
            // Pridobi column podatke
            const columns = getColumnData();
            
            // Pridobi table visibility podatke
            const tables = getTableVisibilityData();
            
            // Pridobi admin objekt (npr. allBrokenMediaAdmin, allCartLiveAdmin, itd.)
            const adminObj = adminObjName && window[adminObjName] ? window[adminObjName] : null;
            
            if (!adminObj) {
                reject(new Error('[SAVE USERPREF] Admin object is not available'));
                return;
            }
            
            // PHP pričakuje user_preferences kot array
            const formData = new FormData();
            formData.append('action', 'allsnippets__ajax__save_userpref_admin_page');
            formData.append('user_id', adminObj.user_id);
            formData.append('nonce', adminObj.nonce);
            formData.append('plugin_slug', pluginSlug);
            formData.append('page_slug', pageSlug);
            formData.append('user_preferences[limit]', limitToSave);
            formData.append('user_preferences[orderby]', sorting.orderby);
            formData.append('user_preferences[order]', sorting.order);
            
            // Dodaj filter-radio podatke
            Object.keys(filterRadioData).forEach(function(filterKey) {
                formData.append('user_preferences[' + filterKey + ']', filterRadioData[filterKey]);
            });
            
            // Dodaj filter-toggle podatke (objekti)
            Object.keys(filterToggleData).forEach(function(filterKey) {
                Object.keys(filterToggleData[filterKey]).forEach(function(filterPath) {
                    formData.append('user_preferences[' + filterKey + '][' + filterPath + ']', filterToggleData[filterKey][filterPath]);
                });
            });
            
            // Dodaj filter-dropdown podatke (objekti)
            Object.keys(filterDropdownData).forEach(function(filterKey) {
                Object.keys(filterDropdownData[filterKey]).forEach(function(filterPath) {
                    formData.append('user_preferences[' + filterKey + '][' + filterPath + ']', filterDropdownData[filterKey][filterPath]);
                });
            });
            
            // Dodaj column podatke
            columns.forEach(function(column, index) {
                formData.append('user_preferences[columns][' + index + ']', column);
            });
            
            // Dodaj table visibility podatke (če obstajajo)
            if (tables.length > 0) {
                tables.forEach(function(table, index) {
                    formData.append('user_preferences[tables][' + index + ']', table);
                });
            }
            
            // PHP uporablja wp_send_json_success() kar vrne JSON format: {success: true, data: "..."}
            fetch(adminObj.ajaxurl, {
                method: 'POST',
                body: formData,
                signal: signal // Omogoči preklic zahteve
            })
            .then(response => {
                // Preveri, če je bila zahteva preklicana
                if (signal.aborted) {
                    reject(new Error('Request aborted'));
                    return;
                }
                return response.json();
            })
            .then(response => {
                if (signal.aborted) {
                    reject(new Error('Request aborted'));
                    return;
                }
                currentSaveController = null; // Očisti controller, ko je zahteva končana
                resolve(response);
            })
            .catch(error => {
                if (error.name === 'AbortError') {
                    // Zahteva je bila preklicana - to je normalno, ne logiraj kot napako
                    return;
                }
                console.error('[SAVE USERPREF] Error:', error);
                currentSaveController = null; // Očisti controller tudi pri napaki
                reject(error);
            });
        });
    }
    } // Konec init funkcije
    
    // Zaženi inicializacijo
    init();
})();
// KONEC KODE: JavaScript za zanesljivo shranjevanje filtrov, limita in stolpcev


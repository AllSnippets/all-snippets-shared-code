// ZAČETEK KODE: JavaScript za Sidebar Toggle funkcionalnost
// Script se naloži v footer (wp_enqueue_script zadnji parameter je true), zato DOM je že pripravljen
(function() {
    // Toggle sidebar skrij/prikaži (delegiran listener)
    document.addEventListener('click', function(e) {
        const toggleBtn = e.target.closest('.gp-sidebar--toggle-btn');
        if (!toggleBtn) return;
        
        const root = toggleBtn.closest('.gp-sidebar--root');
        if (!root) return;
        
        const adaptiveMargins = document.querySelectorAll('.gp-sidebar--adaptive-margin');
        const icon = toggleBtn.querySelector('.dashicons');
        
        if (adaptiveMargins.length === 0 || !icon) return;
        
        root.classList.toggle('is-hidden');
        // Dodaj/odstrani class na vseh elementih z gp-sidebar--adaptive-margin
        adaptiveMargins.forEach(function(adaptiveMargin) {
            adaptiveMargin.classList.toggle('sidebar-hidden');
        });
        
        // Spremeni puščico
        if (root.classList.contains('is-hidden')) {
            icon.classList.remove('dashicons-arrow-left-alt2');
            icon.classList.add('dashicons-arrow-right-alt2');
        } else {
            icon.classList.remove('dashicons-arrow-right-alt2');
            icon.classList.add('dashicons-arrow-left-alt2');
        }
    });
})();
// KONEC KODE: JavaScript za Sidebar Toggle funkcionalnost


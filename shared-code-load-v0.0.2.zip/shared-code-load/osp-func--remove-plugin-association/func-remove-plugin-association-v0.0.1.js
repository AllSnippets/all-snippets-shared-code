// ZAČETEK KODE: Skupna JavaScript funkcija za brisanje plugin_association z AJAX refresh
(function() {
    // Preverimo, ali obstaja konfiguracija
    if (!window.sharedPageConfig) {
        console.error('[REMOVE PLUGIN ASSOCIATION] window.sharedPageConfig object is missing.');
        return;
    }

    // Destrukturiramo potrebne podatke
    const { pluginSlug, funcName } = window.sharedPageConfig;

    // Helper funkcija za klic osveževanja strani
    function callAjaxRefreshPage() {
        const refreshFuncName = `${funcName}-ajaxRefreshPage`;
        if (typeof window[refreshFuncName] === 'function') {
            window[refreshFuncName]();
        } else {
            console.error('[REMOVE PLUGIN ASSOCIATION] Function', refreshFuncName, 'is missing.');
        }
    }

    // Event listener za gumb
    document.addEventListener('click', function(e) {
        const button = e.target.closest('.gp-delete-all-plugin-associations-btn');
        if (!button) return;
        
        e.preventDefault();
        
        if (!confirm('Are you sure you want to delete all plugin_association values? This action cannot be undone!')) {
            return;
        }

        // Pokaži loading overlay
        const loadingOverlay = document.querySelector('.gp-loading--overlay');
        if (loadingOverlay) {
            loadingOverlay.classList.remove('gp-display-none');
        }

        // Določi pravilno ime akcije (tables ima ednino, ostali množino)
        let actionSuffix = 'associations';
        if (pluginSlug === 'all_db_tables') {
            actionSuffix = 'association';
        }
        const action = `${pluginSlug}__ajax__delete_all_plugin_${actionSuffix}`;

        // Pridobi ajaxurl iz lokaliziranega objekta (npr. allDbUsermetaAdmin.ajaxurl)
        const adminObjName = `${funcName}Admin`;
        const adminObj = window[adminObjName];
        
        if (!adminObj || !adminObj.ajaxurl) {
            console.error(`[REMOVE PLUGIN ASSOCIATION] Object ${adminObjName} or ajaxurl is missing.`);
            if (loadingOverlay) loadingOverlay.classList.add('gp-display-none');
            return;
        }

        const formData = new FormData();
        formData.append('action', action);

        fetch(adminObj.ajaxurl, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(response => {
            // Skrij loading overlay (razen če refresh funkcija tega ne zahteva drugače, ampak tukaj ga skrijemo za vsak slučaj ali pa pustimo odprtega za refresh)
            // Običajno refresh funkcija sama upravlja overlay ali pa se stran osveži. 
            // V prejšnji kodi smo ga skrili preden smo klicali refresh.
            if (loadingOverlay) loadingOverlay.classList.add('gp-display-none');

            if (response.success) {
                callAjaxRefreshPage();
            } else {
                console.error('Delete error:', response.data);
                alert('Error deleting plugin_association values: ' + (response.data && response.data.message ? response.data.message : 'Unknown error'));
            }
        })
        .catch(error => {
            if (loadingOverlay) loadingOverlay.classList.add('gp-display-none');
            console.error('AJAX error:', error);
            alert('Error connecting to server.');
        });
    });

})();
// KONEC KODE: Skupna JavaScript funkcija za brisanje plugin_association z AJAX refresh

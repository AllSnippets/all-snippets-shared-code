// ZAČETEK KODE: JavaScript za filter dropdown open/close funkcionalnost z delegiranimi event listenerji
(function() {
    // Začetek: delegiran filter dropdown funkcionalnost
    document.addEventListener('click', function(e) {
        // Preveri, ali je klik na button ali znotraj button-a
        const button = e.target.closest('.gp-filter-dropdown--button');
        if (button) {
            e.preventDefault();
            e.stopPropagation();
            const root = button.closest('.gp-filter-dropdown--root');
            if (root) {
                const content = root.querySelector('.gp-filter-dropdown--content');
                if (content) {
                    // Preveri, ali je dropdown že odprt
                    const isOpen = content.classList.contains('gp-filter-dropdown--content-open');
                    
                    // Zapri vse dropdown-e
                    const allContents = document.querySelectorAll('.gp-filter-dropdown--content');
                    allContents.forEach(function(otherContent) {
                        otherContent.classList.remove('gp-filter-dropdown--content-open');
                    });
                    
                    // Če dropdown ni bil odprt, ga odpri (accordion vedenje)
                    if (!isOpen) {
                        content.classList.add('gp-filter-dropdown--content-open');
                    }
                }
            }
        }
    });
    
    // Zapri dropdown ko klikneš zunaj
    document.addEventListener('click', function(e) {
        // Preveri, ali klik ni znotraj root elementa
        if (!e.target.closest('.gp-filter-dropdown--root')) {
            const allContents = document.querySelectorAll('.gp-filter-dropdown--content');
            allContents.forEach(function(content) {
                content.classList.remove('gp-filter-dropdown--content-open');
            });
        }
    });
    // Konec: delegiran filter dropdown funkcionalnost
})();
// KONEC KODE: JavaScript za filter dropdown open/close funkcionalnost z delegiranimi event listenerji


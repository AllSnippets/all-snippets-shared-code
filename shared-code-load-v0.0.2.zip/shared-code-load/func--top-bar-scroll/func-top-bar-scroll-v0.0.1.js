// ZAČETEK KODE: Top bar se premika s scrollom kot navaden element
// Script se naloži v footer (wp_enqueue_script zadnji parameter je true), zato DOM je že pripravljen
(function() {
    const initialTop = 50; // Začetna pozicija (top: 50px)
    let ticking = false; // requestAnimationFrame throttle
    
    // Scroll handler z requestAnimationFrame za boljšo performance
    window.addEventListener('scroll', function() {
        if (!ticking) {
            window.requestAnimationFrame(function() {
                const topBar = document.querySelector('.gp-top-bar--root');
                if (topBar) {
                    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
                    const newTop = initialTop - scrollTop;
                    topBar.style.top = newTop + 'px';
                }
                ticking = false;
            });
            ticking = true;
        }
    });
})();
// KONEC KODE: Top bar se premika s scrollom kot navaden element


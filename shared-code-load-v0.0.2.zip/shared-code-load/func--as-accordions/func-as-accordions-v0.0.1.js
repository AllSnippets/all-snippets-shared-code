// ZAČETEK KODE: Advanced Settings Accordions (Main + Info) z delegiranimi event listenerji
// Script se naloži v footer (wp_enqueue_script zadnji parameter je true), zato DOM je že pripravljen
(function() {
    // Helper funkcija za zapiranje vseh info accordionov globalno
    function closeAllInfoAccordions() {
        document.querySelectorAll('.gp-advset--info-acc--root').forEach(el => {
            el.classList.remove('open');
        });
        document.querySelectorAll('.gp-advset--info-acc--title').forEach(el => {
            el.classList.remove('sticky-sub-title');
        });
    }
    
    // MAIN ACCORDION - delegiran listener
    document.addEventListener('click', function(e) {
        const title = e.target.closest('.gp-advset--accordion-title');
        if (!title) return;
        
        const parent = title.closest('.gp-advset--accordion');
        if (!parent) return;
        
        // Če je že odprt, ga zapremo
        if (parent.classList.contains('open')) {
            parent.classList.remove('open');
            title.classList.remove('sticky-title');
            // Zapremo tudi VSE info accordione globalno
            closeAllInfoAccordions();
        } else {
            // Najprej zapremo vse main accordion elemente in odstranimo sticky
            document.querySelectorAll('.gp-advset--accordion').forEach(el => el.classList.remove('open'));
            document.querySelectorAll('.gp-advset--accordion-title').forEach(el => el.classList.remove('sticky-title'));
            
            // Zapremo tudi VSE info accordione globalno
            closeAllInfoAccordions();
            
            // Nato odpremo samo kliknjenega in dodamo sticky
            parent.classList.add('open');
            title.classList.add('sticky-title');
            
            // Scroll na content element
            setTimeout(function() {
                const content = parent.querySelector('.gp-advset--accordion-content');
                if (content) {
                    content.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }, 100);
        }
    });
    
    // INFO ACCORDION - delegiran listener
    document.addEventListener('click', function(e) {
        const title = e.target.closest('.gp-advset--info-acc--title');
        if (!title) return;
        
        const parent = title.closest('.gp-advset--info-acc--root');
        if (!parent) return;
        
        // Če je že odprt, ga zapremo
        if (parent.classList.contains('open')) {
            parent.classList.remove('open');
            title.classList.remove('sticky-sub-title');
        } else {
            // Zapremo VSE info accordione globalno (ne samo znotraj parent accordion-a)
            closeAllInfoAccordions();
            
            // Nato odpremo samo kliknjenega in dodamo sticky-sub-title
            parent.classList.add('open');
            title.classList.add('sticky-sub-title');
            
            // Scroll na content element
            setTimeout(function() {
                const content = parent.querySelector('.gp-advset--info-acc--content');
                if (content) {
                    content.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }, 100);
        }
    });
})();
// KONEC KODE: Advanced Settings Accordions (Main + Info) z delegiranimi event listenerji


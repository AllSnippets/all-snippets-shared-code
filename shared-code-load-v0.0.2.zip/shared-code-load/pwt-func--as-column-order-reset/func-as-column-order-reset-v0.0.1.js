// ZAČETEK KODE: JavaScript za reset vrstnega reda stolpcev
(function() {
    // Funkcija za inicializacijo - počaka, da se objekt lokalizira
    function initColumnOrderReset() {
        // Počakaj, da se sharedPageConfig naloži (iz func-get-page-config.js)
        if (!window.sharedPageConfig) {
            setTimeout(initColumnOrderReset, 50);
            return;
        }
        
        const { pluginSlug, adminObjName } = window.sharedPageConfig;
        
        // Preveri, če objekt obstaja - če ne, počakaj malo in poskusi znova
        if (!window[adminObjName]) {
            // Počakaj 50ms in poskusi znova (maksimalno 20 poskusov = 1 sekunda)
            let attempts = 0;
            const maxAttempts = 20;
            const checkInterval = setInterval(() => {
                attempts++;
                if (window[adminObjName]) {
                    clearInterval(checkInterval);
                    continueInit();
                } else if (attempts >= maxAttempts) {
                    clearInterval(checkInterval);
                    console.error('[COLUMN ORDER RESET] Object', adminObjName, 'does not exist after', maxAttempts * 50, 'ms');
                }
            }, 50);
            return;
        }
        
        continueInit();
        
        function continueInit() {
            document.addEventListener('click', function(e) {
                const resetButton = e.target.closest('.gp-advset--column-order--reset-btn');
                if (resetButton) {
                    e.preventDefault();
                    const pageSlug = resetButton.getAttribute('data-page-slug');
                    if (pageSlug && confirm('Are you sure you want to reset the column order to default?')) {
                        resetColumnOrder(pageSlug);
                    }
                }
            });

            function resetColumnOrder(pageSlug) {
                // Skupni action name za vse vtičnike
                const actionName = 'allsnippets_shared_func__reset_column_order';

                const formData = new FormData();
                formData.append('action', actionName);
                formData.append('plugin_slug', pluginSlug);
                formData.append('nonce', window[adminObjName].nonce);
                formData.append('page_slug', pageSlug);

                fetch(window[adminObjName].ajaxurl, {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin'
                })
                .then(response => response.json())
                .then(resp => {
                    if (resp && resp.success) {
                        // Osveži stran, da se prikaže privzeti vrstni red
                        if (typeof window.allsnippetsAjaxRefreshPage === 'function') {
                            window.allsnippetsAjaxRefreshPage();
                        }
                    } else if (resp && resp.data) {
                        alert('Napaka pri ponastavitvi: ' + resp.data);
                    }
                })
                .catch(error => {
                    console.error('Error resetting column order:', error);
                });
            }
        }
    }
    
    // Začni inicializacijo (funkcija že počaka na window.sharedPageConfig in window[adminObjName])
    initColumnOrderReset();
})();
// KONEC KODE: JavaScript za reset vrstnega reda stolpcev

